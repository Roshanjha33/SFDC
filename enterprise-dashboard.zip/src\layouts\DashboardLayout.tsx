import React, { useState } from 'react';
import {
    Briefcase,
    Layers,
    BarChart3,
    GitBranch,
    Settings,
    Hammer,
    Bell,
    Search,
    ChevronDown
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AgentView } from '../components/AgentView';
import { motion, AnimatePresence } from 'framer-motion';

const AGENTS = [
    { id: 'req-extract', label: 'Requirement Extraction', icon: Layers },
    { id: 'ootb-ref', label: 'D365 OOTB Reference', icon: Briefcase },
    { id: 'fit-gap', label: 'Fit / Gap Analysis', icon: BarChart3 },
    { id: 'target-process', label: 'Target Process Design', icon: GitBranch },
    { id: 'build-compiler', label: 'Build Compiler', icon: Hammer },
    { id: 'governance', label: 'Governance', icon: Settings },
];

export type AgentStatus = 'completed' | 'running' | 'idle' | 'failed';

export interface RunHistoryItem {
    id: string;
    agentName: string;
    timestamp: string;
    status: AgentStatus;
}

export const DashboardLayout: React.FC = () => {
    const [activeAgent, setActiveAgent] = useState('req-extract');
    const [autoRun, setAutoRun] = useState(false);
    const [history, setHistory] = useState<RunHistoryItem[]>([]);

    const handleRunStart = (agentLabel: string) => {
        const newRun: RunHistoryItem = {
            id: Date.now().toString(),
            agentName: agentLabel,
            timestamp: new Date().toLocaleString(),
            status: 'running'
        };
        setHistory(prev => [newRun, ...prev]);
        return newRun.id;
    };

    const handleRunComplete = (runId: string, status: AgentStatus) => {
        setHistory(prev => prev.map(item =>
            item.id === runId ? { ...item, status } : item
        ));
    };

    return (
        <div className="min-h-screen bg-cosmic-950 text-slate-200 flex flex-col font-sans selection:bg-cosmic-blue/30 overflow-hidden">
            {/* Top Header */}
            <header className="h-16 border-b border-white/5 bg-slate-900/50 backdrop-blur-md flex items-center justify-between px-6 z-50">
                <div className="flex items-center gap-8">
                    <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cosmic-blue to-cosmic-purple flex items-center justify-center shadow-lg shadow-blue-500/20">
                            <span className="font-bold text-white text-lg">A</span>
                        </div>
                        <span className="font-bold text-white tracking-tight text-lg">Agent<span className="text-cosmic-blue">OS</span></span>
                    </div>

                    <div className="relative hidden md:block">
                        <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                        <input
                            type="text"
                            placeholder="Search resources..."
                            className="bg-slate-950/50 border border-slate-800 rounded-full py-2 pl-9 pr-4 text-sm focus:outline-none focus:border-cosmic-blue/50 w-64 transition-all"
                        />
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <button className="relative p-2 rounded-full hover:bg-white/5 transition-colors">
                        <Bell className="w-5 h-5 text-slate-400" />
                        <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-cosmic-neon border-2 border-slate-900" />
                    </button>
                    <div className="h-8 w-[1px] bg-slate-800" />
                    <button className="flex items-center gap-2 hover:bg-white/5 px-2 py-1 rounded-lg transition-colors">
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white ring-2 ring-slate-800">
                            JD
                        </div>
                        <span className="text-sm font-medium hidden md:block">John Doe</span>
                        <ChevronDown className="w-4 h-4 text-slate-500" />
                    </button>
                </div>
            </header>

            {/* Main Navigation Tabs */}
            <div className="bg-slate-900/30 border-b border-white/5 px-6 pt-2">
                <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
                    {AGENTS.map((agent) => {
                        const Icon = agent.icon;
                        const isActive = activeAgent === agent.id;

                        return (
                            <button
                                key={agent.id}
                                onClick={() => {
                                    setActiveAgent(agent.id);
                                    setAutoRun(false);
                                }}
                                className={cn(
                                    "flex items-center gap-2 px-4 py-3 min-w-max rounded-t-lg transition-all border-t-2 relative group",
                                    isActive
                                        ? "bg-slate-800/40 text-white border-cosmic-blue shadow-[0_-5px_15px_-5px_rgba(59,130,246,0.1)]"
                                        : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
                                )}
                            >
                                <Icon className={cn("w-4 h-4 transition-colors", isActive ? "text-cosmic-blue" : "text-slate-500 group-hover:text-slate-300")} />
                                <span className="text-sm font-medium">{agent.label}</span>
                                {isActive && (
                                    <div className="absolute inset-0 bg-gradient-to-b from-cosmic-blue/5 to-transparent pointer-events-none" />
                                )}
                            </button>
                        )
                    })}
                </div>
            </div>

            {/* Status Banner */}
            <div className="px-6 py-2 bg-emerald-500/5 border-b border-emerald-500/10 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-emerald-400">
                    <span className="px-2 py-0.5 rounded text-xs font-bold bg-emerald-500/10 border border-emerald-500/20 uppercase tracking-wider">Completed</span>
                    <span className="text-slate-400">System check finished successfully. All agents ready.</span>
                </div>
                <span className="text-xs text-slate-500 font-mono">v2.4.0-stable</span>
            </div>

            {/* Workspace Content */}
            <main className="flex-1 overflow-hidden relative">
                {/* Subtle Grid Background */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />

                <div className="absolute inset-0 z-10">
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={activeAgent}
                            initial={{ opacity: 0, scale: 0.98 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.98 }}
                            transition={{ duration: 0.2 }}
                            className="h-full"
                        >
                            <AgentView
                                agentId={activeAgent}
                                agentLabel={AGENTS.find(a => a.id === activeAgent)?.label || ''}
                                autoRun={autoRun}
                                history={history}
                                onRunStart={() => handleRunStart(AGENTS.find(a => a.id === activeAgent)?.label || '')}
                                onRunComplete={(runId, status) => handleRunComplete(runId, status)}
                                onNext={() => {
                                    const currentIndex = AGENTS.findIndex(a => a.id === activeAgent);
                                    const nextIndex = (currentIndex + 1) % AGENTS.length;
                                    setActiveAgent(AGENTS[nextIndex].id);
                                    setAutoRun(true);
                                }}
                            />
                        </motion.div>
                    </AnimatePresence>
                </div>
            </main>

        </div>
    );
};
