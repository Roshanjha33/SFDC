import React, { useState, useEffect } from 'react';
import {
    Briefcase,
    Layers,
    BarChart3,
    GitBranch,
    Settings,
    Hammer,
    Bell,
    Search,
    ChevronDown,
    History
} from 'lucide-react';
import { cn } from '../lib/utils';
import { AgentView } from '../components/AgentView';
import { motion, AnimatePresence } from 'framer-motion';
import type { AgentStatus, RunHistoryItem } from '../types';

const AGENTS = [
    { id: 'req-extract', label: 'Requirement Extraction', icon: Layers },
    { id: 'ootb-ref', label: 'D365 OOTB Reference', icon: Briefcase },
    { id: 'fit-gap', label: 'Fit / Gap Analysis', icon: BarChart3 },
    { id: 'target-process', label: 'Target Process Design', icon: GitBranch },
    { id: 'build-compiler', label: 'Build Compiler', icon: Hammer },
    { id: 'governance', label: 'Execute Manifest', icon: Settings },
];

interface DashboardLayoutProps {
    history: RunHistoryItem[];
    onRunStart: (agentLabel: string) => string;
    onRunComplete: (runId: string, status: AgentStatus) => void;
    initialAgentId?: string;
    initialAutoRun?: boolean;
    onViewHistory: () => void;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
    history,
    onRunStart,
    onRunComplete,
    initialAgentId = 'req-extract',
    initialAutoRun = false,
    onViewHistory
}) => {
    const [activeAgent, setActiveAgent] = useState(initialAgentId);
    const [autoRun, setAutoRun] = useState(initialAutoRun);

    // Update state if props change (re-initialization or external control attempt)
    useEffect(() => {
        if (initialAgentId) setActiveAgent(initialAgentId);
        if (initialAutoRun) setAutoRun(initialAutoRun);
    }, [initialAgentId, initialAutoRun]);

    return (
        <div className="min-h-screen bg-cosmic-950 text-slate-200 flex flex-col font-sans selection:bg-cosmic-blue/30 overflow-hidden">
            {/* Top Header */}
            <header className="h-16 border-b border-white/5 bg-slate-900/50 backdrop-blur-md flex items-center justify-between px-6 z-50">
                <div className="flex items-center gap-8">
                    <div className="flex items-center gap-2">
                        <div className="relative group perspective-1000">
                            <div className="absolute inset-0 bg-cosmic-blue/50 blur-[20px] rounded-full group-hover:bg-cosmic-blue/80 transition-all duration-500 animate-pulse" />
                            <svg className="w-10 h-10 drop-shadow-2xl transform transition-transform duration-500 group-hover:scale-110" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <defs>
                                    <linearGradient id="gradStroke" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stopColor="#2962FF" /> {/* Blue */}
                                        <stop offset="50%" stopColor="#00B8D4" /> {/* Cyan */}
                                        <stop offset="100%" stopColor="#00E5FF" /> {/* Bright Cyan */}
                                    </linearGradient>
                                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                                        <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                                        <feMerge>
                                            <feMergeNode in="coloredBlur" />
                                            <feMergeNode in="SourceGraphic" />
                                        </feMerge>
                                    </filter>
                                </defs>
                                <g className="origin-center">
                                    {/* Modern Hexagonal C: Stroked path */}
                                    {/* Starts top-right, goes top, left, bottom, bottom-right */}
                                    <path
                                        d="M 85 25 L 75 8 L 25 8 L 5 50 L 25 92 L 75 92 L 85 75"
                                        stroke="url(#gradStroke)"
                                        strokeWidth="12"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        filter="url(#glow)"
                                    />

                                </g>
                            </svg>
                        </div>
                        <span className="font-bold text-white tracking-tight text-lg">Cognizant <span className="text-cosmic-blue">Agentic OS</span></span>
                    </div>

                    <div className="relative hidden md:block">
                        <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                        <input
                            type="text"
                            placeholder="Search resources..."
                            className="bg-slate-950/50 border border-slate-800 rounded-full py-2 pl-9 pr-4 text-sm focus:outline-none focus:border-cosmic-blue/50 w-64 transition-all"
                        />
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <button
                        onClick={onViewHistory}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors text-sm font-medium"
                    >
                        <History className="w-4 h-4" />
                        History
                    </button>
                    <button className="relative p-2 rounded-full hover:bg-white/5 transition-colors">
                        <Bell className="w-5 h-5 text-slate-400" />
                        <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-cosmic-neon border-2 border-slate-900" />
                    </button>
                    <div className="h-8 w-[1px] bg-slate-800" />
                    <button className="flex items-center gap-2 hover:bg-white/5 px-2 py-1 rounded-lg transition-colors">
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold text-white ring-2 ring-slate-800">
                            JD
                        </div>
                        <span className="text-sm font-medium hidden md:block">John Doe</span>
                        <ChevronDown className="w-4 h-4 text-slate-500" />
                    </button>
                </div>
            </header>

            {/* Main Navigation Tabs */}
            <div className="bg-slate-900/30 border-b border-white/5 px-6 pt-2">
                <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide">
                    {AGENTS.map((agent) => {
                        const Icon = agent.icon;
                        const isActive = activeAgent === agent.id;

                        return (
                            <button
                                key={agent.id}
                                onClick={() => {
                                    setActiveAgent(agent.id);
                                    setAutoRun(false);
                                }}
                                className={cn(
                                    "flex items-center gap-2 px-4 py-3 min-w-max rounded-t-lg transition-all border-t-2 relative group",
                                    isActive
                                        ? "bg-slate-800/40 text-white border-cosmic-blue shadow-[0_-5px_15px_-5px_rgba(59,130,246,0.1)]"
                                        : "border-transparent text-slate-400 hover:text-white hover:bg-white/5"
                                )}
                            >
                                <Icon className={cn("w-4 h-4 transition-colors", isActive ? "text-cosmic-blue" : "text-slate-500 group-hover:text-slate-300")} />
                                <span className="text-sm font-medium">{agent.label}</span>
                                {isActive && (
                                    <div className="absolute inset-0 bg-gradient-to-b from-cosmic-blue/5 to-transparent pointer-events-none" />
                                )}
                            </button>
                        )
                    })}
                </div>
            </div>

            {/* Status Banner */}
            <div className="px-6 py-2 bg-emerald-500/5 border-b border-emerald-500/10 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-emerald-400">
                    <span className="px-2 py-0.5 rounded text-xs font-bold bg-emerald-500/10 border border-emerald-500/20 uppercase tracking-wider">Completed</span>
                    <span className="text-slate-400">System check finished successfully. All agents ready.</span>
                </div>
                <span className="text-xs text-slate-500 font-mono">v2.4.0-stable</span>
            </div>

            {/* Workspace Content */}
            <main className="flex-1 overflow-hidden relative">
                {/* Subtle Grid Background */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />

                <div className="absolute inset-0 z-10">
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={activeAgent}
                            initial={{ opacity: 0, scale: 0.98 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.98 }}
                            transition={{ duration: 0.2 }}
                            className="h-full"
                        >
                            <AgentView
                                agentId={activeAgent}
                                agentLabel={AGENTS.find(a => a.id === activeAgent)?.label || ''}
                                autoRun={autoRun}
                                history={history}
                                onRunStart={() => onRunStart(AGENTS.find(a => a.id === activeAgent)?.label || '')}
                                onRunComplete={(runId, status) => onRunComplete(runId, status)}
                                onNext={() => {
                                    const currentIndex = AGENTS.findIndex(a => a.id === activeAgent);
                                    const nextIndex = (currentIndex + 1) % AGENTS.length;
                                    setActiveAgent(AGENTS[nextIndex].id);
                                    setAutoRun(true);
                                }}
                            />
                        </motion.div>
                    </AnimatePresence>
                </div>
            </main>

        </div>
    );
};

