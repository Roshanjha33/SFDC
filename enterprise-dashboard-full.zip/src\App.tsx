import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import LoginPage from './pages/LoginPage';
import { DashboardLayout } from './layouts/DashboardLayout';
import RunHistoryPage from './pages/RunHistoryPage';
import type { AgentStatus, RunHistoryItem } from './types';

function App() {
  const [view, setView] = useState<'login' | 'history' | 'dashboard'>('login');
  const [history, setHistory] = useState<RunHistoryItem[]>([]);
  const [dashboardConfig, setDashboardConfig] = useState({
    agentId: 'req-extract',
    autoRun: false
  });

  // Load mocks if empty
  // useEffect(() => {
  //   setHistory([
  //       { id: 'run-1234', agentName: 'Requirement Extraction', timestamp: '2/14/2026, 10:00:00 AM', status: 'completed' },
  //       { id: 'run-5678', agentName: 'Governance', timestamp: '2/14/2026, 11:30:00 AM', status: 'failed' },
  //   ])
  // }, []);

  const handleRunStart = (agentLabel: string) => {
    const newRun: RunHistoryItem = {
      id: Date.now().toString(),
      agentName: agentLabel,
      timestamp: new Date().toLocaleString(),
      status: 'running'
    };
    setHistory(prev => [newRun, ...prev]);
    return newRun.id;
  };

  const handleRunComplete = (runId: string, status: AgentStatus) => {
    setHistory(prev => prev.map(item =>
      item.id === runId ? { ...item, status } : item
    ));
  };

  const handleRerun = (runId: string) => {
    const run = history.find(r => r.id === runId);
    if (!run) return;

    // Map agent name back to ID (simple find for now)
    // In a real app we'd store agentId in history too
    // const agentId = AGENTS.find(a => a.label === run.agentName)?.id || 'req-extract';
    // MOCK mapping for now:
    let agentId = 'req-extract';
    if (run.agentName.includes('Governance') || run.agentName.includes('Execute')) agentId = 'governance';
    if (run.agentName.includes('Compiler')) agentId = 'build-compiler';
    if (run.agentName.includes('Process')) agentId = 'target-process';
    if (run.agentName.includes('Fit')) agentId = 'fit-gap';
    if (run.agentName.includes('OOTB')) agentId = 'ootb-ref';

    setDashboardConfig({ agentId, autoRun: true });
    setView('dashboard');
  };

  const handleStop = (runId: string) => {
    setHistory(prev => prev.map(item =>
      item.id === runId && item.status === 'running'
        ? { ...item, status: 'failed' } // Or 'cancelled' if we had that status
        : item
    ));
  };

  return (
    <div className="bg-cosmic-950 min-h-screen text-slate-200 antialiased">
      <AnimatePresence mode="wait">
        {view === 'login' && (
          <motion.div
            key="login"
            exit={{ opacity: 0, scale: 1.05, filter: "blur(10px)" }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 z-50"
          >
            <LoginPage onLogin={() => setView('history')} />
          </motion.div>
        )}

        {view === 'history' && (
          <motion.div
            key="history"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 z-40"
          >
            <RunHistoryPage
              history={history}
              onRerun={handleRerun}
              onStop={handleStop}
              onContinue={() => setView('dashboard')}
            />
          </motion.div>
        )}

        {view === 'dashboard' && (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            <DashboardLayout
              history={history}
              onRunStart={handleRunStart}
              onRunComplete={handleRunComplete}
              initialAgentId={dashboardConfig.agentId}
              initialAutoRun={dashboardConfig.autoRun}
              onViewHistory={() => setView('history')}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}



export default App;
