import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, StopCircle, SkipForward, FileText, Clock, Terminal, Upload, Settings, AlertCircle, Trash2, Plug, Loader2, Check, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'framer-motion';
import { azureOpenAI } from '../lib/azureOpenAI';
import type { AzureConfig, ChatMessage } from '../lib/azureOpenAI';

// Types
import type { RunHistoryItem, AgentStatus } from '../types';

interface AgentViewProps {
    agentId: string;
    agentLabel: string;
    onNext: () => void;
    autoRun?: boolean;
    history: RunHistoryItem[];
    onRunStart: () => string;
    onRunComplete: (runId: string, status: AgentStatus) => void;
}

const INNER_TABS = ['Summary', 'Input', 'Configuration', 'Prompt', 'Output'];

export const AgentView: React.FC<AgentViewProps> = ({ agentId, agentLabel, onNext, autoRun, history, onRunStart, onRunComplete }) => {
    const [activeTab, setActiveTab] = useState('Summary');
    const [status, setStatus] = useState<AgentStatus>('idle');
    const [progress, setProgress] = useState(0);
    const [files, setFiles] = useState<File[]>([]);
    const [connectionStatus, setConnectionStatus] = useState<'idle' | 'connecting' | 'connected' | 'failed'>('idle');
    const [agentResponse, setAgentResponse] = useState<string>('');
    const [azureConfig, setAzureConfig] = useState<AzureConfig>({
        endpoint: import.meta.env.VITE_AZURE_OPENAI_ENDPOINT || '',
        apiKey: import.meta.env.VITE_AZURE_OPENAI_API_KEY || '',
        deployment: import.meta.env.VITE_AZURE_OPENAI_DEPLOYMENT || ''
    });

    const fileInputRef = useRef<HTMLInputElement>(null);
    const currentRunId = useRef<string | null>(null);
    const [isApproved, setIsApproved] = useState(false);

    // Simulation Logic (Fallback)
    useEffect(() => {
        if (status === 'running' && connectionStatus !== 'connected') {
            const interval = setInterval(() => {
                setProgress(prev => {
                    if (prev >= 100) {
                        setStatus('completed');
                        setActiveTab('Output'); // Auto-switch to output on completion
                        if (currentRunId.current) {
                            onRunComplete(currentRunId.current, 'completed');
                            currentRunId.current = null;
                        }
                        return 100;
                    }
                    return prev + 2; // Increment progress
                });
            }, 100);
            return () => clearInterval(interval);
        } else if (status === 'idle') {
            setProgress(0);
        }
    }, [status, connectionStatus]);

    const handleRun = async () => {
        if (!isApproved) return;
        setStatus('running');
        setProgress(0);
        currentRunId.current = onRunStart();

        if (connectionStatus === 'connected') {
            try {
                // Construct messages
                const messages: ChatMessage[] = [
                    {
                        role: 'system',
                        content: `You are an enterprise analyst agent. Your goal is to extract requirements from the provided document. Output format: JSON with 'id', 'description', 'priority'.`
                    },
                    {
                        role: 'user',
                        content: `Extract requirements from these files: ${files.map(f => f.name).join(', ')}. (Note: File content reading is simulated here, but assume context is provided).`
                    }
                ];

                // Simulate progress for UI feedback while waiting
                const progressInterval = setInterval(() => {
                    setProgress(prev => Math.min(prev + 5, 90));
                }, 500);

                const response = await azureOpenAI.sendMessage(messages, azureConfig);

                clearInterval(progressInterval);
                setProgress(100);
                setAgentResponse(response);
                setStatus('completed');
                setActiveTab('Output');

                if (currentRunId.current) {
                    onRunComplete(currentRunId.current, 'completed');
                    currentRunId.current = null;
                }

            } catch (error) {
                console.error("Agent Run Failed:", error);
                setStatus('failed');
                setAgentResponse("Error: " + (error as Error).message);
                if (currentRunId.current) {
                    onRunComplete(currentRunId.current, 'failed');
                    currentRunId.current = null;
                }
            }
        }
    };

    const handleStop = () => {
        setStatus('idle');
        setProgress(0);
    };

    const handleReset = () => {
        setStatus('idle');
        setProgress(0);
        setActiveTab('Input');
        setFiles([]);
        setAgentResponse('');
    };

    // Auto-run logic
    useEffect(() => {
        if (autoRun && status === 'idle' && isApproved) {
            handleRun();
        }
    }, [autoRun, isApproved]);

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setFiles(prev => [...prev, ...Array.from(e.target.files!)]);
        }
    };

    const removeFile = (index: number) => {
        setFiles(prev => prev.filter((_, i) => i !== index));
    };

    const triggerFileUpload = () => {
        fileInputRef.current?.click();
    };

    const handleConnect = () => {
        setConnectionStatus('connecting');
        // Simple validation simulation
        setTimeout(() => {
            if (azureConfig.endpoint && azureConfig.apiKey && azureConfig.deployment) {
                setConnectionStatus('connected');
            } else {
                setConnectionStatus('failed');
            }
        }, 1000);
    };

    const downloadJSON = () => {
        const data = agentResponse ? { response: agentResponse } : {
            agent: agentId,
            status: "success",
            requirements: [
                { "id": "REQ-001", "desc": "User authentication via SSO", "priority": "High" },
                { "id": "REQ-002", "desc": "Data export to PDF", "priority": "Medium" }
            ]
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${agentId}_output.json`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const downloadExcel = () => {
        // Simulating Excel with CSV
        const csvContent = "ID,Description,Priority\nREQ-001,User authentication via SSO,High\nREQ-002,Data export to PDF,Medium";
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${agentId}_report.csv`; // Using .csv for simplicity, browsers open this in Excel
        a.click();
        URL.revokeObjectURL(url);
    };

    const StatusIcon = ({ status }: { status: AgentStatus }) => {
        switch (status) {
            case 'completed': return <Check className="w-4 h-4 text-cosmic-neon" />;
            case 'running': return <div className="w-4 h-4 border-2 border-cosmic-blue border-r-transparent rounded-full animate-spin" />;
            case 'failed': return <div className="w-4 h-4 rounded-full bg-red-500" />;
            default: return <div className="w-4 h-4 rounded-full bg-slate-600" />;
        }
    };

    const renderTabContent = () => {
        switch (activeTab) {
            case 'Summary':
                return (
                    <div className="space-y-6">
                        <div>
                            <h2 className="text-xl font-semibold text-white mb-2 flex items-center gap-2">
                                <FileText className="w-5 h-5 text-cosmic-cyan" />
                                {agentLabel} Overview
                            </h2>
                            <p className="text-slate-400 leading-relaxed max-w-2xl">
                                This agent is responsible for analyzing input documents, extracting key requirements, and mapping them against the standard schema.
                                It utilizes advanced NLP models to ensure high-fidelity data extraction and compliance checking.
                            </p>
                        </div>

                        {status === 'completed' && (
                            <div className="mt-8 p-6 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                                <div className="flex items-center gap-3 mb-4">
                                    <Check className="w-6 h-6 text-emerald-400" />
                                    <div>
                                        <h3 className="text-emerald-400 font-semibold">Extraction Complete</h3>
                                        <p className="text-emerald-400/70 text-sm">Processed {files.length > 0 ? files.length : 3} documents successfully.</p>
                                    </div>
                                </div>
                                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                                    <motion.div
                                        initial={{ width: 0 }}
                                        animate={{ width: '100%' }}
                                        className="h-full bg-emerald-500"
                                    />
                                </div>
                            </div>
                        )}

                        {status === 'running' && (
                            <div className="mt-8">
                                <div className="flex justify-between text-sm mb-2">
                                    <span className="text-slate-400">Processing...</span>
                                    <span className="text-cosmic-blue font-mono">{progress}%</span>
                                </div>
                                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                                    <motion.div
                                        animate={{ width: `${progress}%` }}
                                        className="h-full bg-cosmic-blue shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                                    />
                                </div>
                            </div>
                        )}
                    </div>
                );
            case 'Input':
                return (
                    <div className="space-y-6">
                        <div
                            onClick={triggerFileUpload}
                            className="flex flex-col items-center justify-center h-64 border-2 border-dashed border-slate-700 rounded-xl bg-slate-900/30 hover:bg-slate-900/50 hover:border-cosmic-blue transition-all cursor-pointer group"
                        >
                            <div className="p-4 rounded-full bg-slate-800 group-hover:bg-cosmic-blue/20 mb-4 transition-colors">
                                <Upload className="w-8 h-8 text-slate-400 group-hover:text-cosmic-blue" />
                            </div>
                            <p className="text-slate-300 font-medium">Click to upload documents</p>
                            <p className="text-slate-500 text-sm mt-1">PDF, DOCX, or TXT (Max 10MB)</p>
                            <input
                                type="file"
                                ref={fileInputRef}
                                className="hidden"
                                multiple
                                onChange={handleFileUpload}
                            />
                        </div>

                        {files.length > 0 && (
                            <div className="space-y-2">
                                <h4 className="text-sm font-medium text-slate-300">Uploaded Files ({files.length})</h4>
                                <div className="space-y-2">
                                    {files.map((file, idx) => (
                                        <div key={idx} className="flex items-center justify-between p-3 bg-slate-900/50 border border-slate-700 rounded-lg group">
                                            <div className="flex items-center gap-3">
                                                <FileText className="w-4 h-4 text-cosmic-blue" />
                                                <span className="text-sm text-slate-200">{file.name}</span>
                                                <span className="text-xs text-slate-500">({(file.size / 1024).toFixed(1)} KB)</span>
                                            </div>
                                            <button
                                                onClick={() => removeFile(idx)}
                                                className="p-1.5 hover:bg-red-500/10 rounded text-slate-500 hover:text-red-400 transition-colors"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                );
            case 'Configuration':
                return (
                    <div className="space-y-6 max-w-xl">
                        {agentId === 'req-extract' && (
                            <div className="p-4 rounded-xl bg-cosmic-blue/10 border border-cosmic-blue/30 space-y-4 mb-6">
                                <h4 className="text-cosmic-blue font-semibold text-sm flex items-center gap-2">
                                    <Settings className="w-4 h-4" />
                                    Agent API Configuration
                                </h4>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">Azure OpenAI Endpoint</label>
                                    <input
                                        type="text"
                                        className="w-full bg-slate-900/80 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:border-cosmic-blue outline-none font-mono text-xs"
                                        placeholder="https://your-resource.openai.azure.com/"
                                        value={azureConfig.endpoint}
                                        onChange={(e) => setAzureConfig({ ...azureConfig, endpoint: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">API Key</label>
                                    <input
                                        type="password"
                                        className="w-full bg-slate-900/80 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:border-cosmic-blue outline-none font-mono text-xs"
                                        placeholder="sk-..."
                                        value={azureConfig.apiKey}
                                        onChange={(e) => setAzureConfig({ ...azureConfig, apiKey: e.target.value })}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">Deployment Name</label>
                                    <input
                                        type="text"
                                        className="w-full bg-slate-900/80 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:border-cosmic-blue outline-none font-mono text-xs"
                                        placeholder="gtp-4o"
                                        value={azureConfig.deployment}
                                        onChange={(e) => setAzureConfig({ ...azureConfig, deployment: e.target.value })}
                                    />
                                </div>
                                <div className="flex justify-end pt-2">
                                    <button
                                        onClick={handleConnect}
                                        disabled={connectionStatus === 'connected' || connectionStatus === 'connecting'}
                                        className={cn(
                                            "px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2",
                                            connectionStatus === 'idle' && "bg-cosmic-blue hover:bg-blue-600 text-white shadow-lg shadow-blue-500/20",
                                            connectionStatus === 'connecting' && "bg-slate-700 text-slate-300 cursor-wait",
                                            connectionStatus === 'connected' && "bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 cursor-default",
                                            connectionStatus === 'failed' && "bg-red-500/20 text-red-400 border border-red-500/50"
                                        )}
                                    >
                                        {connectionStatus === 'idle' && <>Connect <Plug className="w-4 h-4" /></>}
                                        {connectionStatus === 'connecting' && <>Connecting... <Loader2 className="w-4 h-4 animate-spin" /></>}
                                        {connectionStatus === 'connected' && <>Connected <Check className="w-4 h-4" /></>}
                                        {connectionStatus === 'failed' && <>Connection Failed <X className="w-4 h-4" /></>}
                                    </button>
                                </div>
                            </div>
                        )}

                        {agentId === 'ootb-ref' && (
                            <div className="p-4 rounded-xl bg-cosmic-purple/10 border border-cosmic-purple/30 space-y-4 mb-6">
                                <h4 className="text-cosmic-purple font-semibold text-sm flex items-center gap-2">
                                    <Settings className="w-4 h-4" />
                                    D365 Connection Settings
                                </h4>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">Environment URL</label>
                                    <input
                                        type="url"
                                        className="w-full bg-slate-900/80 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:border-cosmic-purple outline-none font-mono text-xs"
                                        placeholder="https://org.crm.dynamics.com"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">Password / Access Key</label>
                                    <input
                                        type="password"
                                        className="w-full bg-slate-900/80 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:border-cosmic-purple outline-none font-mono text-xs"
                                        placeholder="••••••••"
                                    />
                                </div>
                                <div className="flex justify-end pt-2">
                                    <button
                                        onClick={handleConnect}
                                        disabled={connectionStatus === 'connected' || connectionStatus === 'connecting'}
                                        className={cn(
                                            "px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2",
                                            connectionStatus === 'idle' && "bg-cosmic-purple hover:bg-purple-600 text-white shadow-lg shadow-purple-500/20",
                                            connectionStatus === 'connecting' && "bg-slate-700 text-slate-300 cursor-wait",
                                            connectionStatus === 'connected' && "bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 cursor-default",
                                            connectionStatus === 'failed' && "bg-red-500/20 text-red-400 border border-red-500/50"
                                        )}
                                    >
                                        {connectionStatus === 'idle' && <>Connect to D365 <Plug className="w-4 h-4" /></>}
                                        {connectionStatus === 'connecting' && <>Connecting... <Loader2 className="w-4 h-4 animate-spin" /></>}
                                        {connectionStatus === 'connected' && <>Connected <Check className="w-4 h-4" /></>}
                                        {connectionStatus === 'failed' && <>Connection Failed <X className="w-4 h-4" /></>}
                                    </button>
                                </div>
                            </div>
                        )}

                        {agentId !== 'ootb-ref' && (
                            <>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">Model Sensitivity</label>
                                    <input type="range" className="w-full accent-cosmic-blue" min="0" max="100" defaultValue="75" />
                                    <div className="flex justify-between text-xs text-slate-500">
                                        <span>Strict (Low Hallucination)</span>
                                        <span>Creative (High Recall)</span>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">Max Retry Attempts</label>
                                    <select className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-200 focus:border-cosmic-blue outline-none">
                                        <option>0 (Fail Fast)</option>
                                        <option>1</option>
                                        <option>3 (Standard)</option>
                                        <option>5</option>
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium text-slate-300">Output Format Logic</label>
                                    <div className="flex items-center gap-2 text-sm text-slate-400">
                                        <input type="checkbox" defaultChecked className="rounded border-slate-700 bg-slate-900 text-cosmic-blue" />
                                        <span>Include metadata references</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm text-slate-400">
                                        <input type="checkbox" className="rounded border-slate-700 bg-slate-900 text-cosmic-blue" />
                                        <span>Enable debug logging</span>
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                );
            case 'Prompt':
                return (
                    <div className="h-full flex flex-col gap-4">
                        <div className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-lg flex items-start gap-3">
                            <AlertCircle className="w-5 h-5 text-amber-500 mt-0.5" />
                            <div>
                                <h4 className="text-amber-400 font-medium text-sm">System Instruction</h4>
                                <p className="text-amber-400/70 text-xs">Modifying the system prompt may affect extraction accuracy.</p>
                            </div>
                        </div>
                        <div className="flex-1 relative">
                            <textarea
                                className="w-full h-full bg-slate-900/50 border border-slate-700 rounded-xl p-4 text-slate-200 font-mono text-sm focus:border-cosmic-blue outline-none resize-none"
                                defaultValue={`You are an enterprise analyst agent.
Your goal is to extract requirements from the provided document.
Output format: JSON with 'id', 'description', 'priority'.`}
                            />
                            <div className="absolute bottom-4 right-4">
                                <button className="bg-slate-800 hover:bg-slate-700 text-xs text-white px-3 py-1.5 rounded-lg border border-slate-700 transition-colors">
                                    Restore Default
                                </button>
                            </div>
                        </div>
                    </div>
                );
            case 'Output':
                if (status !== 'completed' && status !== 'idle' && status !== 'failed') { // Show empty state if not completed
                    return (
                        <div className="flex flex-col items-center justify-center h-64 text-slate-500">
                            <Clock className="w-12 h-12 mb-4 opacity-50" />
                            <p>Run the agent to generate output.</p>
                        </div>
                    )
                }

                if (status === 'failed') {
                    return (
                        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400">
                            <h3 className="font-semibold mb-2">Execution Failed</h3>
                            <pre className="whitespace-pre-wrap text-sm">{agentResponse}</pre>
                        </div>
                    );
                }

                return (
                    <div className="space-y-6">
                        <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-4 font-mono text-sm text-slate-300 h-64 overflow-y-auto">
                            <pre>{agentResponse || `{
  "agent": "${agentId}",
  "status": "success",
  "requirements": [
    { "id": "REQ-001", "desc": "User authentication via SSO", "priority": "High" },
    { "id": "REQ-002", "desc": "Data export to PDF", "priority": "Medium" }
  ]
}`}</pre>
                        </div>
                        <div className="flex items-center gap-4">
                            <button
                                onClick={downloadExcel}
                                className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-500/20 active:scale-95"
                            >
                                <FileText className="w-4 h-4" />
                                Download Excel Report
                            </button>
                            <button
                                onClick={downloadJSON}
                                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2 transition-colors border border-slate-700 active:scale-95"
                            >
                                <Terminal className="w-4 h-4" />
                                Download JSON
                            </button>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    }

    return (
        <div className="flex h-full gap-6 p-6 overflow-hidden">
            {/* Main Content Area */}
            <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex-1 flex flex-col gap-6"
            >
                {/* Inner Navigation */}
                <div className="flex items-center gap-2 border-b border-slate-800 pb-1">
                    {INNER_TABS.filter(tab => {
                        if (agentId === 'ootb-ref') {
                            return tab !== 'Input' && tab !== 'Prompt';
                        }
                        if (agentId === 'target-process') {
                            return tab !== 'Input';
                        }
                        return true;
                    }).map((tab) => {
                        let displayLabel = tab;
                        if (agentId === 'fit-gap' && tab === 'Input') {
                            displayLabel = 'Upload';
                        }
                        return (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab)}
                                className={cn(
                                    "px-4 py-2 text-sm font-medium rounded-t-lg transition-all relative overflow-hidden",
                                    activeTab === tab
                                        ? "text-white bg-slate-800/50 border-b-2 border-cosmic-blue"
                                        : "text-slate-400 hover:text-white hover:bg-slate-800/30"
                                )}
                            >
                                {displayLabel}
                                {activeTab === tab && (
                                    <motion.div layoutId="activeTabGlow" className="absolute inset-0 bg-cosmic-blue/5" />
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* Content Panel */}
                <div className="flex-1 glass-card rounded-2xl p-6 relative overflow-hidden flex flex-col">
                    <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                        <Terminal className="w-64 h-64 text-cosmic-blue" />
                    </div>

                    <div className="relative z-10 flex-1 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-700">
                        {renderTabContent()}
                    </div>

                    {/* Action Buttons Footer */}
                    <div className="relative z-10 pt-6 mt-2 border-t border-slate-800/50 flex items-center gap-4">
                        <button
                            onClick={() => setIsApproved(true)}
                            disabled={isApproved || status === 'running'}
                            className={cn(
                                "text-white px-6 py-2.5 rounded-lg shadow-lg font-medium flex items-center gap-2 transition-all active:scale-95",
                                isApproved
                                    ? "bg-emerald-500/20 text-emerald-400 cursor-default shadow-none"
                                    : "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-500/20"
                            )}
                        >
                            {isApproved ? (
                                <>
                                    Approved <Check className="w-4 h-4" />
                                </>
                            ) : (
                                <>
                                    Approve <Check className="w-4 h-4" />
                                </>
                            )}
                        </button>

                        {status === 'running' ? (
                            <button
                                onClick={handleStop}
                                className="bg-red-500/10 hover:bg-red-500/20 text-red-500 px-6 py-2.5 rounded-lg border border-red-500/50 transition-all flex items-center gap-2"
                            >
                                <StopCircle className="w-4 h-4 fill-current" />
                                Stop Run
                            </button>
                        ) : (
                            <button
                                onClick={handleRun}
                                disabled={!isApproved}
                                className="disabled:opacity-50 disabled:cursor-not-allowed bg-cosmic-blue hover:bg-blue-600 text-white px-6 py-2.5 rounded-lg shadow-lg shadow-blue-500/20 font-medium flex items-center gap-2 transition-all active:scale-95"
                            >
                                <Play className="w-4 h-4 fill-current" />
                                {status === 'completed' ? 'Run Again' : 'Run Agent'}
                            </button>
                        )}


                        <button
                            onClick={handleReset}
                            disabled={(!isApproved && status !== 'completed' && status !== 'failed') || (status !== 'completed' && status !== 'failed')}
                            className="disabled:opacity-50 disabled:cursor-not-allowed bg-slate-800 hover:bg-slate-700 text-slate-200 px-6 py-2.5 rounded-lg border border-slate-700 transition-all flex items-center gap-2 hover:border-slate-500"
                        >
                            <RotateCcw className="w-4 h-4" />
                            Re-run
                        </button>

                        <button
                            onClick={onNext}
                            disabled={!isApproved}
                            className="disabled:opacity-50 disabled:cursor-not-allowed bg-slate-800 hover:bg-slate-700 text-slate-200 px-6 py-2.5 rounded-lg border border-slate-700 transition-all flex items-center gap-2 hover:border-slate-500 ml-auto group"
                        >
                            Run next Agent
                            <SkipForward className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </button>
                    </div>
                </div>
            </motion.div>

            {/* Right Panel: Run History */}
            <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="w-80 flex flex-col glass-card rounded-2xl overflow-hidden"
            >
                <div className="p-4 border-b border-white/10 bg-slate-900/40 backdrop-blur-md">
                    <h3 className="font-semibold text-white flex items-center gap-2">
                        <Clock className="w-4 h-4 text-cosmic-purple" />
                        Run History
                    </h3>
                </div>
                <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
                    <div className="space-y-1">
                        {history.map((item) => (
                            <div
                                key={item.id}
                                className="p-3 rounded-xl hover:bg-white/5 transition-colors border border-transparent hover:border-white/5 group cursor-default"
                            >
                                <div className="flex justify-between items-start mb-1">
                                    <span className="text-xs font-mono text-slate-500">{item.timestamp}</span>
                                    <span className={cn(
                                        "text-xs font-bold px-2 py-0.5 rounded-full capitalize",
                                        item.status === 'completed' ? "bg-emerald-500/10 text-emerald-400" :
                                            item.status === 'running' ? "bg-blue-500/10 text-blue-400" :
                                                item.status === 'failed' ? "bg-red-500/10 text-red-400" : "bg-slate-500/10 text-slate-400"
                                    )}>
                                        {item.status}
                                    </span>
                                </div>
                                <div className="flex items-center justify-between">
                                    <div className="text-sm text-slate-300 font-medium">
                                        Run <span className="text-cosmic-blue">{item.agentName}</span>
                                    </div>
                                    <StatusIcon status={item.status} />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </motion.div>
        </div>
    );
};
