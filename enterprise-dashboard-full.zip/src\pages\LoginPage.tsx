import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Lock, ArrowRight } from 'lucide-react';

interface LoginPageProps {
    onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        // Simulate network request
        setTimeout(() => {
            setIsLoading(false);
            onLogin();
        }, 1500);
    };

    return (
        <div className="min-h-screen bg-cosmic-950 flex items-center justify-center relative overscroll-none overflow-hidden">
            {/* Background Effects */}
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cosmic-blue/20 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cosmic-purple/10 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute top-[20%] right-[10%] w-[20%] h-[20%] bg-cosmic-cyan/10 rounded-full blur-[80px] pointer-events-none" />

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="w-full max-w-md z-10 p-8"
            >
                <div className="glass-card p-8 rounded-2xl border border-white/10 shadow-2xl relative overflow-hidden backdrop-blur-xl bg-slate-900/40">
                    {/* Decorative Top Border */}
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cosmic-blue via-cosmic-cyan to-cosmic-purple" />

                    <div className="mb-8 text-center">
                        <div className="mx-auto w-24 h-24 flex items-center justify-center mb-6 relative group perspective-1000">
                            <div className="absolute inset-0 bg-cosmic-blue/50 blur-[30px] rounded-full group-hover:bg-cosmic-blue/80 transition-all duration-500 animate-pulse" />
                            <svg className="w-20 h-20 drop-shadow-2xl transform transition-transform duration-500 group-hover:scale-110" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <defs>
                                    <linearGradient id="gradStroke" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stopColor="#2962FF" /> {/* Blue */}
                                        <stop offset="50%" stopColor="#00B8D4" /> {/* Cyan */}
                                        <stop offset="100%" stopColor="#00E5FF" /> {/* Bright Cyan */}
                                    </linearGradient>
                                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                                        <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                                        <feMerge>
                                            <feMergeNode in="coloredBlur" />
                                            <feMergeNode in="SourceGraphic" />
                                        </feMerge>
                                    </filter>
                                </defs>
                                <g className="origin-center">
                                    <path
                                        d="M 85 25 L 75 8 L 25 8 L 5 50 L 25 92 L 75 92 L 85 75"
                                        stroke="url(#gradStroke)"
                                        strokeWidth="12"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        filter="url(#glow)"
                                    />
                                </g>
                            </svg>
                        </div>
                        <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">Cognizant Agentic OS</h1>
                        <p className="text-slate-400 text-sm">Secure Terminal Login</p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-xs uppercase tracking-wider text-slate-400 font-semibold ml-1">Username / ID</label>
                            <div className="relative group">
                                <User className="absolute left-3 top-3 w-5 h-5 text-slate-500 group-focus-within:text-cosmic-blue transition-colors" />
                                <input
                                    type="text"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="w-full bg-slate-950/50 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-white placeholder-slate-600 focus:outline-none focus:border-cosmic-blue focus:ring-1 focus:ring-cosmic-blue transition-all"
                                    placeholder="agent.admin"
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs uppercase tracking-wider text-slate-400 font-semibold ml-1">Password</label>
                            <div className="relative group">
                                <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-500 group-focus-within:text-cosmic-blue transition-colors" />
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="w-full bg-slate-950/50 border border-slate-700 rounded-lg py-2.5 pl-10 pr-4 text-white placeholder-slate-600 focus:outline-none focus:border-cosmic-blue focus:ring-1 focus:ring-cosmic-blue transition-all"
                                    placeholder="••••••••"
                                />
                            </div>
                        </div>

                        <div className="flex items-center justify-between text-xs text-slate-400">
                            <label className="flex items-center cursor-pointer hover:text-white transition-colors">
                                <input type="checkbox" className="mr-2 rounded border-slate-700 bg-slate-900/50 text-cosmic-blue focus:ring-offset-0 focus:ring-0 checked:bg-cosmic-blue" />
                                Remember Session
                            </label>
                            <a href="#" className="hover:text-cosmic-cyan transition-colors">Recover Access?</a>
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full bg-gradient-to-r from-cosmic-blue to-cosmic-purple hover:from-blue-600 hover:to-purple-600 text-white font-semibold py-3 rounded-lg shadow-lg shadow-blue-500/20 transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 group relative overflow-hidden"
                        >
                            {isLoading ? (
                                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            ) : (
                                <>
                                    <span>Authenticate</span>
                                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                                </>
                            )}
                            {/* Shine effect */}
                            <div className="absolute top-0 -left-full w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12 group-hover:animate-[shine_1.5s_infinite]" />
                        </button>
                    </form>

                    <div className="mt-8 text-center">
                        <p className="text-xs text-slate-600">
                            Protected by Enterprise Grade Encryption. <br />
                            Unauthorize access is strictly prohibited.
                        </p>
                    </div>
                </div>
            </motion.div>
        </div>
    );
};

export default LoginPage;
