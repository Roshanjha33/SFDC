export interface AzureConfig {
    endpoint: string;
    apiKey: string;
    deployment: string;
    apiVersion?: string;
}

export interface ChatMessage {
    role: 'system' | 'user' | 'assistant';
    content: string;
}

export interface ChatResponse {
    choices: {
        message: {
            content: string;
        };
    }[];
}

export const azureOpenAI = {
    sendMessage: async (messages: ChatMessage[], config: AzureConfig): Promise<string> => {
        const { endpoint, apiKey, deployment, apiVersion = '2023-05-15' } = config;

        // Ensure endpoint ends with /
        const formattedEndpoint = endpoint.endsWith('/') ? endpoint : `${endpoint}/`;
        const url = `${formattedEndpoint}openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'api-key': apiKey
                },
                body: JSON.stringify({
                    messages: messages,
                    temperature: 0.7,
                    max_tokens: 800,
                    top_p: 0.95,
                    frequency_penalty: 0,
                    presence_penalty: 0,
                    stop: null
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.error?.message || `API Error: ${response.status} ${response.statusText}`);
            }

            const data: ChatResponse = await response.json();
            return data.choices[0]?.message?.content || '';
        } catch (error) {
            console.error('Azure OpenAI API Error:', error);
            throw error;
        }
    }
};
