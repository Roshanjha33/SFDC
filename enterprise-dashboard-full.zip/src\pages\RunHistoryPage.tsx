import React from 'react';
import { motion } from 'framer-motion';
import { Play, Square, ArrowRight, Clock, CheckCircle2, XCircle, AlertCircle, RotateCcw } from 'lucide-react';
import type { RunHistoryItem } from '../types';
import { cn } from '../lib/utils';

interface RunHistoryPageProps {
    history: RunHistoryItem[];
    onRerun: (runId: string) => void;
    onStop: (runId: string) => void;
    onContinue: () => void;
}

const StatusIcon = ({ status }: { status: RunHistoryItem['status'] }) => {
    switch (status) {
        case 'completed': return <CheckCircle2 className="w-5 h-5 text-emerald-400" />;
        case 'running': return <RotateCcw className="w-5 h-5 text-cosmic-blue animate-spin" />; // Or a spinner
        case 'failed': return <XCircle className="w-5 h-5 text-red-400" />;
        default: return <AlertCircle className="w-5 h-5 text-slate-400" />;
    }
};

const RunHistoryPage: React.FC<RunHistoryPageProps> = ({ history, onRerun, onStop, onContinue }) => {
    return (
        <div className="min-h-screen bg-cosmic-950 text-slate-200 flex flex-col items-center justify-center p-8 relative overflow-hidden">
            {/* Background Gradients */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cosmic-blue/10 rounded-full blur-[100px]" />
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cosmic-purple/10 rounded-full blur-[100px]" />
            </div>

            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-5xl z-10"
            >
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-4">
                        <div className="relative group perspective-1000">
                            <div className="absolute inset-0 bg-cosmic-blue/50 blur-[20px] rounded-full group-hover:bg-cosmic-blue/80 transition-all duration-500 animate-pulse" />
                            <svg className="w-12 h-12 drop-shadow-2xl transform transition-transform duration-500 group-hover:scale-110" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <defs>
                                    <linearGradient id="gradStroke" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stopColor="#2962FF" />
                                        <stop offset="50%" stopColor="#00B8D4" />
                                        <stop offset="100%" stopColor="#00E5FF" />
                                    </linearGradient>
                                    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                                        <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                                        <feMerge>
                                            <feMergeNode in="coloredBlur" />
                                            <feMergeNode in="SourceGraphic" />
                                        </feMerge>
                                    </filter>
                                </defs>
                                <g className="origin-center">
                                    <path
                                        d="M 85 25 L 75 8 L 25 8 L 5 50 L 25 92 L 75 92 L 85 75"
                                        stroke="url(#gradStroke)"
                                        strokeWidth="12"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        filter="url(#glow)"
                                    />
                                </g>
                            </svg>
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-white mb-2">Agent Run History</h1>
                            <p className="text-slate-400">Review past agent activities and manage ongoing tasks.</p>
                        </div>
                    </div>
                    <button
                        onClick={onContinue}
                        className="group flex items-center gap-2 px-6 py-3 bg-cosmic-blue hover:bg-cosmic-blue/90 text-white rounded-lg font-medium transition-all shadow-lg shadow-cosmic-blue/20"
                    >
                        Go to Dashboard
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                </div>

                <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
                    {history.length === 0 ? (
                        <div className="p-12 text-center text-slate-500">
                            <Clock className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p className="text-lg">No run history available yet.</p>
                            <p className="text-sm">Start your first agent run in the dashboard.</p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="border-b border-white/5 bg-white/5">
                                        <th className="p-4 font-semibold text-slate-300">Run ID</th>
                                        <th className="p-4 font-semibold text-slate-300">Agent Name</th>
                                        <th className="p-4 font-semibold text-slate-300">Timestamp</th>
                                        <th className="p-4 font-semibold text-slate-300">Status</th>
                                        <th className="p-4 font-semibold text-slate-300 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {history.map((run) => (
                                        <tr key={run.id} className="border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
                                            <td className="p-4 font-mono text-sm text-slate-400">#{run.id.slice(-6)}</td>
                                            <td className="p-4 font-medium text-white">{run.agentName}</td>
                                            <td className="p-4 text-slate-400">{run.timestamp}</td>
                                            <td className="p-4">
                                                <div className="flex items-center gap-2">
                                                    <StatusIcon status={run.status} />
                                                    <span className={cn(
                                                        "capitalize text-sm font-medium",
                                                        run.status === 'completed' ? "text-emerald-400" :
                                                            run.status === 'running' ? "text-cosmic-blue" :
                                                                run.status === 'failed' ? "text-red-400" : "text-slate-400"
                                                    )}>
                                                        {run.status}
                                                    </span>
                                                </div>
                                            </td>
                                            <td className="p-4 text-right">
                                                <div className="flex items-center justify-end gap-2">
                                                    {run.status === 'running' && (
                                                        <button
                                                            onClick={() => onStop(run.id)}
                                                            className="p-2 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors"
                                                            title="Stop Run"
                                                        >
                                                            <Square className="w-4 h-4 fill-current" />
                                                        </button>
                                                    )}
                                                    <button
                                                        onClick={() => onRerun(run.id)}
                                                        className="p-2 hover:bg-cosmic-blue/20 text-cosmic-blue rounded-lg transition-colors"
                                                        title="Rerun"
                                                    >
                                                        <Play className="w-4 h-4 fill-current" />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </motion.div >
        </div >
    );
};

export default RunHistoryPage;
