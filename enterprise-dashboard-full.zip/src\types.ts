export type AgentStatus = 'completed' | 'running' | 'idle' | 'failed';

export interface RunHistoryItem {
    id: string;
    agentName: string;
    timestamp: string;
    status: AgentStatus;
}
