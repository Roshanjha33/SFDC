
import { mockAiService } from './services/mockAiService.js';
import ConnectView from './components/ConnectView.js';
import ReviewView from './components/ReviewView.js';

const App = () => {
    const [view, setView] = React.useState('connect'); // 'connect' | 'review'
    const [sfStatus, setSfStatus] = React.useState('disconnected');
    const [d365Status, setD365Status] = React.useState('disconnected');
    const [isConnecting, setIsConnecting] = React.useState(null); // 'sf' | 'd365' | 'analyze' | null
    const [analysisResults, setAnalysisResults] = React.useState([]);

    const handleConnect = async (type, creds) => {
        setIsConnecting(type);
        try {
            if (type === 'sf') {
                await mockAiService.connectSalesforce(creds.clientId, creds.clientSecret);
                setSfStatus('connected');
            } else if (type === 'd365') {
                await mockAiService.connectD365(creds.url, creds.tenantId);
                setD365Status('connected');
            } else if (type === 'analyze') {
                const results = await mockAiService.fetchAndAnalyzeMetadata();
                setAnalysisResults(results);
                setView('review');
            }
        } catch (error) {
            console.error(error);
            alert(`Connection failed: ${error.message}`);
        } finally {
            setIsConnecting(null);
        }
    };

    return (
        <React.Fragment>
            {view === 'connect' && (
                <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
                    <ConnectView
                        onConnect={handleConnect}
                        sfStatus={sfStatus}
                        d365Status={d365Status}
                        isConnecting={isConnecting}
                    />
                </div>
            )}

            {view === 'review' && (
                <div className="h-screen bg-slate-50">
                    <ReviewView
                        analysisResults={analysisResults}
                        onAction={(id, action) => console.log(id, action)}
                    />
                </div>
            )}
        </React.Fragment>
    );
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
