
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const mockAiService = {
    async connectSalesforce(clientId, clientSecret) {
        await delay(1500);
        if (!clientId) throw new Error("Client ID is required");
        return {
            status: 'connected',
            orgName: 'Salesforce Production',
            version: '57.0'
        };
    },

    async connectD365(url, tenantId) {
        await delay(1500);
        if (!url) throw new Error("Resource URL is required");
        return {
            status: 'connected',
            orgName: 'D365 Sales Contoso',
            version: '9.2'
        };
    },

    async fetchAndAnalyzeMetadata() {
        // Stimulate fetching metadata from both source and AI analysis
        await delay(3000);

        return [
            {
                id: 1,
                sourceEntity: { name: 'Account', label: 'Account', fields: 150 },
                targetEntity: { name: 'account', label: 'Account', fields: 142 },
                similarity: 0.98,
                suggestion: 'MERGE',
                reasoning: 'Both entities represent business organizations with highly overlapping schemas (Name, Address, Phone).',
                status: 'pending'
            },
            {
                id: 2,
                sourceEntity: { name: 'Contact', label: 'Contact', fields: 85 },
                targetEntity: { name: 'contact', label: 'Contact', fields: 80 },
                similarity: 0.95,
                suggestion: 'MERGE',
                reasoning: 'Standard person contact record. Direct mapping available for 90% of fields.',
                status: 'pending'
            },
            {
                id: 3,
                sourceEntity: { name: 'Opportunity', label: 'Opportunity', fields: 120 },
                targetEntity: { name: 'opportunity', label: 'Opportunity', fields: 110 },
                similarity: 0.92,
                suggestion: 'MERGE',
                reasoning: 'Sales deal tracking. Stages differ slightly but core fields (Amount, CloseDate) align.',
                status: 'pending'
            },
            {
                id: 4,
                sourceEntity: { name: 'Custom_Vehicle__c', label: 'Vehicle', fields: 25 },
                targetEntity: null,
                similarity: 0.12,
                suggestion: 'CREATE_NEW',
                reasoning: 'No corresponding entity found in D365. "Vehicle" concept appears unique to source customization.',
                status: 'pending'
            },
            {
                id: 5,
                sourceEntity: { name: 'Invoice_Header__c', label: 'Invoice', fields: 45 },
                targetEntity: { name: 'invoice', label: 'Invoice', fields: 50 },
                similarity: 0.88,
                suggestion: 'MERGE',
                reasoning: 'Strong match with OOB Invoice entity, though custom fields will need extensions.',
                status: 'pending'
            },
            {
                id: 6,
                sourceEntity: { name: 'Web_Visit__c', label: 'Web Visit', fields: 15 },
                targetEntity: null,
                similarity: 0.05,
                suggestion: 'CREATE_NEW',
                reasoning: 'Tracking analytics data. No simplified match in standard D365 Sales tables.',
                status: 'pending'
            }
        ];
    }
};
