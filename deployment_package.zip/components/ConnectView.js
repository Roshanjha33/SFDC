
const ConnectView = ({ onConnect, sfStatus, d365Status, isConnecting }) => {
    const [sfCreds, setSfCreds] = React.useState({ clientId: '3MVG9...', clientSecret: '******' });
    const [d365Creds, setD365Creds] = React.useState({ url: 'https://org.crm.dynamics.com', tenantId: '******' });

    const isConnectedAll = sfStatus === 'connected' && d365Status === 'connected';

    return (
        <div className="max-w-4xl mx-auto p-6 space-y-8 animate-fade-in">
            <div className="text-center mb-10">
                <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600 mb-2">
                    CRM Metadata Mapper
                </h1>
                <p className="text-slate-500 text-lg">AI-powered schema analysis and migration assistant</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
                {/* Salesforce Card */}
                <div className={`glass-panel p-6 rounded-2xl relative transition-all duration-300 ${sfStatus === 'connected' ? 'border-green-400 shadow-green-100' : 'hover:shadow-lg'}`}>
                    <div className="absolute top-4 right-4 text-2xl text-[#00A1E0]">
                        <i className="fa-brands fa-salesforce"></i>
                    </div>
                    <h2 className="text-xl font-semibold mb-6 flex items-center">
                        Salesforce Source
                        {sfStatus === 'connected' && <span className="ml-3 text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full"><i className="fas fa-check mr-1"></i> Connected</span>}
                    </h2>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Consumer Key</label>
                            <input
                                type="text"
                                className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                                value={sfCreds.clientId}
                                onChange={e => setSfCreds({ ...sfCreds, clientId: e.target.value })}
                                disabled={sfStatus === 'connected'}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Consumer Secret</label>
                            <input
                                type="password"
                                className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                                value={sfCreds.clientSecret}
                                onChange={e => setSfCreds({ ...sfCreds, clientSecret: e.target.value })}
                                disabled={sfStatus === 'connected'}
                            />
                        </div>
                        {sfStatus !== 'connected' && (
                            <button
                                onClick={() => onConnect('sf', sfCreds)}
                                disabled={isConnecting}
                                className="w-full py-2 bg-[#00A1E0] hover:bg-[#008CA0] text-white rounded-lg font-medium transition-colors flex justify-center items-center"
                            >
                                {isConnecting === 'sf' ? <div className="loader border-white/30 border-t-white h-5 w-5"></div> : 'Connect Salesforce'}
                            </button>
                        )}
                    </div>
                </div>

                {/* D365 Card */}
                <div className={`glass-panel p-6 rounded-2xl relative transition-all duration-300 ${d365Status === 'connected' ? 'border-purple-400 shadow-purple-100' : 'hover:shadow-lg'}`}>
                    <div className="absolute top-4 right-4 text-2xl text-[#7F52FF]">
                        <i className="fa-brands fa-microsoft"></i>
                    </div>
                    <h2 className="text-xl font-semibold mb-6 flex items-center">
                        Dynamics 365 Target
                        {d365Status === 'connected' && <span className="ml-3 text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full"><i className="fas fa-check mr-1"></i> Connected</span>}
                    </h2>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Env URL</label>
                            <input
                                type="text"
                                className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all"
                                value={d365Creds.url}
                                onChange={e => setD365Creds({ ...d365Creds, url: e.target.value })}
                                disabled={d365Status === 'connected'}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Tenant ID</label>
                            <input
                                type="password"
                                className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all"
                                value={d365Creds.tenantId}
                                onChange={e => setD365Creds({ ...d365Creds, tenantId: e.target.value })}
                                disabled={d365Status === 'connected'}
                            />
                        </div>
                        {d365Status !== 'connected' && (
                            <button
                                onClick={() => onConnect('d365', d365Creds)}
                                disabled={isConnecting}
                                className="w-full py-2 bg-[#7F52FF] hover:bg-[#6A40EE] text-white rounded-lg font-medium transition-colors flex justify-center items-center"
                            >
                                {isConnecting === 'd365' ? <div className="loader border-white/30 border-t-white h-5 w-5"></div> : 'Connect D365'}
                            </button>
                        )}
                    </div>
                </div>
            </div>

            {isConnectedAll && (
                <div className="flex justify-center pt-8 animate-fade-in">
                    <button
                        onClick={() => onConnect('analyze')}
                        disabled={isConnecting}
                        className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-lg font-bold rounded-full shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all flex items-center space-x-3"
                    >
                        {isConnecting === 'analyze' ? (
                            <>
                                <div className="loader border-white/30 border-t-white"></div>
                                <span>AI Analyzing Metadata...</span>
                            </>
                        ) : (
                            <>
                                <i className="fa-solid fa-wand-magic-sparkles"></i>
                                <span>Start AI Analysis</span>
                            </>
                        )}
                    </button>
                </div>
            )}
        </div>
    );
};

export default ConnectView;
