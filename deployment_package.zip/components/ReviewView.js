
const ReviewView = ({ analysisResults, onAction }) => {
    return (
        <div className="h-full flex flex-col animate-fade-in">
            <header className="flex-none p-6 border-b border-slate-200 bg-white/50 backdrop-blur-md">
                <div className="flex justify-between items-center max-w-7xl mx-auto w-full">
                    <h1 className="text-2xl font-bold text-slate-800">
                        <i className="fa-solid fa-wand-magic-sparkles text-purple-500 mr-2"></i>
                        AI Metadata Recommendations
                    </h1>
                    <div className="text-sm text-slate-500">
                        Analyzed 6 Entities • 4 Merge Candidates • 2 New Candidates
                    </div>
                </div>
            </header>

            <main className="flex-1 overflow-auto p-6 bg-slate-50/50">
                <div className="max-w-7xl mx-auto space-y-4">
                    {analysisResults.map((item) => (
                        <div key={item.id} className="glass-panel rounded-xl p-0 overflow-hidden hover:shadow-md transition-shadow">
                            <div className="flex items-stretch min-h-[100px]">
                                {/* Source Column */}
                                <div className="w-1/3 p-6 border-r border-slate-100 bg-blue-50/30">
                                    <div className="flex items-center space-x-2 text-blue-800 font-semibold mb-2">
                                        <i className="fa-brands fa-salesforce"></i>
                                        <span>{item.sourceEntity.label}</span>
                                    </div>
                                    <div className="text-sm text-slate-500 font-mono mb-2">{item.sourceEntity.name}</div>
                                    <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        {item.sourceEntity.fields} Fields
                                    </div>
                                </div>

                                {/* AI Middle Column */}
                                <div className="w-1/3 p-6 flex flex-col justify-center items-center text-center border-r border-slate-100 relative group">
                                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <span className={`text-xs font-bold px-2 py-1 rounded ${item.similarity > 0.8 ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                                            {Math.round(item.similarity * 100)}% Match
                                        </span>
                                    </div>

                                    <div className="mb-3">
                                        {item.suggestion === 'MERGE' ? (
                                            <div className="h-10 w-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-lg shadow-sm">
                                                <i className="fa-solid fa-code-merge"></i>
                                            </div>
                                        ) : (
                                            <div className="h-10 w-10 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center text-lg shadow-sm">
                                                <i className="fa-solid fa-plus"></i>
                                            </div>
                                        )}
                                    </div>

                                    <h3 className="font-bold text-slate-800 mb-1">
                                        {item.suggestion === 'MERGE' ? 'Merge Recommendation' : 'Create New Table'}
                                    </h3>
                                    <p className="text-xs text-slate-500 leading-relaxed max-w-[80%]">
                                        {item.reasoning}
                                    </p>
                                </div>

                                {/* Target/Action Column */}
                                <div className="w-1/3 p-6 bg-purple-50/30 flex flex-col justify-between">
                                    {item.targetEntity ? (
                                        <div className="mb-4">
                                            <div className="flex items-center space-x-2 text-purple-800 font-semibold mb-2">
                                                <i className="fa-brands fa-microsoft"></i>
                                                <span>{item.targetEntity.label}</span>
                                            </div>
                                            <div className="text-sm text-slate-500 font-mono">{item.targetEntity.name}</div>
                                        </div>
                                    ) : (
                                        <div className="mb-4 text-slate-400 italic text-sm py-2">
                                            No matching entity found in Target
                                        </div>
                                    )}

                                    <div className="flex space-x-2 mt-auto">
                                        <button className="flex-1 py-2 bg-slate-800 text-white rounded-lg text-sm font-medium hover:bg-slate-700 transition-colors shadow-sm">
                                            Accept AI
                                        </button>
                                        <button className="px-3 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors">
                                            <i className="fa-solid fa-pen"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );
};

export default ReviewView;
