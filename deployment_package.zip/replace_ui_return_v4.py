import os

file_path = "index.html"
new_return_block = r"""            return (
                <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-8 animate-fade-in font-sans">
                    
                    <div className="w-full max-w-6xl space-y-8">
                        {/* Header */}
                        <div className="text-center space-y-2 mb-10">
                            <h1 className="text-3xl font-light text-slate-800">
                                <span className="font-semibold text-[#00A1E0]">CRM</span> Intelligence Bridge
                            </h1>
                            <p className="text-slate-500">Connect your source and target systems to begin analysis</p>
                        </div>

                        {/* Main Grid: Side-by-Side Connectors */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                            
                            {/* LEFT: Salesforce Connector */}
                            <div className="bg-white rounded-xl shadow-2xl border border-slate-100 overflow-hidden relative transform transition-all hover:shadow-3xl">
                                {/* Status Indicator */}
                                <div className={`h-1.5 w-full ${sfStatus === 'connected' ? 'bg-green-500' : 'bg-[#00A1E0]'}`}></div>
                                
                                <div className="p-8 space-y-6">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-3">
                                            <span className="text-[#00A1E0] text-4xl"><i className="fa-brands fa-salesforce"></i></span>
                                            <div>
                                                <h2 className="text-xl font-bold text-slate-800">Salesforce</h2>
                                                <p className="text-xs text-slate-400 font-medium tracking-wide upppercase">SOURCE SYSTEM</p>
                                            </div>
                                        </div>
                                        {sfStatus === 'connected' && (
                                            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold border border-green-200">
                                                <i className="fas fa-check mr-1"></i> CONNECTED
                                            </span>
                                        )}
                                    </div>

                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Connection Method</label>
                                            <div className="relative">
                                                <select 
                                                    value={authType} 
                                                    onChange={(e) => setAuthType(e.target.value)}
                                                    className="w-full pl-4 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:ring-2 focus:ring-[#00A1E0] focus:border-[#00a1e0] appearance-none cursor-pointer font-medium text-sm transition-all hover:border-slate-300"
                                                >
                                                    <option value="demo">Demo / Simulation (Offline)</option>
                                                    <option value="oauth">Login with Salesforce Account</option>
                                                </select>
                                                <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-slate-400">
                                                    <i className="fa-solid fa-chevron-down text-sm"></i>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Dynamic Content based on Selection */}
                                        <div className="bg-slate-50 rounded-lg p-5 border border-slate-100 min-h-[140px] flex flex-col justify-center">
                                            {authType === 'demo' ? (
                                                <div className="flex items-start space-x-3 animate-fade-in">
                                                    <i className="fa-solid fa-flask text-blue-500 mt-1"></i>
                                                    <div className="text-sm text-slate-600">
                                                        <p className="font-semibold text-slate-800 mb-1">Contoso Demo Org</p>
                                                        <p className="text-xs leading-relaxed">
                                                            Connects to a simulated Salesforce environment populated with sample Account and Contact data. Perfect for testing without credentials.
                                                        </p>
                                                    </div>
                                                </div>
                                            ) : (
                                                <div className="flex items-start space-x-3 animate-fade-in">
                                                    <i className="fa-solid fa-globe text-[#00A1E0] mt-1"></i>
                                                    <div className="text-sm text-slate-600">
                                                        <p className="font-semibold text-slate-800 mb-1">Production / Sandbox</p>
                                                        <p className="text-xs leading-relaxed">
                                                            Redirects to Salesforce to authorize access. Requires a configured Connected App Callback URL.
                                                        </p>
                                                        
                                                        <div className="mt-3 flex items-center space-x-2">
                                                            <select 
                                                                value={environment}
                                                                onChange={(e) => setEnvironment(e.target.value)}
                                                                className="text-xs bg-white border border-slate-300 rounded px-2 py-1 focus:ring-1 focus:ring-[#00A1E0]"
                                                            >
                                                                <option value="production">Production</option>
                                                                <option value="sandbox">Sandbox</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        {/* Error Display */}
                                        {errorMessage && (
                                            <div className="p-3 bg-red-50 border border-red-100 rounded-lg animate-fade-in flex items-start space-x-2">
                                                <i className="fa-solid fa-circle-exclamation text-red-500 mt-0.5 text-sm"></i>
                                                <div className="text-xs text-red-600">{errorMessage}</div>
                                            </div>
                                        )}
                                    </div>

                                    {/* Footer Button */}
                                    <button 
                                        onClick={handleSignIn}
                                        disabled={isConnecting === 'sf' || sfStatus === 'connected'}
                                        className={`w-full py-3 rounded-lg font-bold shadow-md transition-all transform active:scale-95 flex items-center justify-center space-x-2 text-sm ${
                                            sfStatus === 'connected' 
                                            ? 'bg-slate-100 text-slate-400 cursor-default shadow-none border border-slate-200'
                                            : 'bg-[#009EDB] hover:bg-[#008cc2] text-white hover:shadow-lg'
                                        } ${isConnecting === 'sf' ? 'opacity-75 cursor-wait' : ''}`}
                                    >
                                        {isConnecting === 'sf' ? (
                                            <><i className="fa-solid fa-circle-notch fa-spin"></i><span>Connecting...</span></>
                                        ) : sfStatus === 'connected' ? (
                                            <span>Source Connected</span>
                                        ) : (
                                            <span>{authType === 'demo' ? 'Connect to Simulation' : 'Sign in with Salesforce'}</span>
                                        )}
                                    </button>
                                </div>
                            </div>

                            {/* RIGHT: Dynamics 365 Connector */}
                            <div className="bg-white rounded-xl shadow-2xl border border-slate-100 overflow-hidden relative transform transition-all hover:shadow-3xl">
                                {/* Status Indicator */}
                                <div className={`h-1.5 w-full ${d365Status === 'connected' ? 'bg-green-500' : 'bg-purple-600'}`}></div>

                                <div className="p-8 space-y-6">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-3">
                                            <span className="text-purple-600 text-4xl"><i className="fa-brands fa-microsoft"></i></span>
                                            <div>
                                                <h2 className="text-xl font-bold text-slate-800">Dynamics 365</h2>
                                                <p className="text-xs text-slate-400 font-medium tracking-wide upppercase">TARGET SYSTEM</p>
                                            </div>
                                        </div>
                                        {d365Status === 'connected' && (
                                            <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold border border-green-200">
                                                <i className="fas fa-check mr-1"></i> CONNECTED
                                            </span>
                                        )}
                                    </div>

                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Target Instance</label>
                                            <div className="bg-purple-50 rounded-lg p-5 border border-purple-100 min-h-[140px] flex flex-col justify-center">
                                                 <div className="flex items-center space-x-3 mb-2">
                                                    <div className="h-8 w-8 bg-white rounded-md flex items-center justify-center shadow-sm text-purple-600">
                                                        <i className="fa-solid fa-building"></i>
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-semibold text-slate-800">Contoso Sales Environment</p>
                                                        <p className="text-xs text-slate-500">{d365Creds.url}</p>
                                                    </div>
                                                 </div>
                                                 <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                                                    Authenticated as <strong>Global Administrator</strong> via Azure AD. 
                                                    Write permissions enabled for Account and Contact entities.
                                                 </p>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Footer Button */}
                                    <button 
                                        onClick={() => onConnect('d365', d365Creds)}
                                        disabled={d365Status === 'connected' || isConnecting === 'd365'}
                                        className={`w-full py-3 rounded-lg font-bold shadow-md transition-all transform active:scale-95 flex items-center justify-center space-x-2 text-sm ${
                                            d365Status === 'connected'
                                            ? 'bg-slate-100 text-slate-400 cursor-default shadow-none border border-slate-200'
                                            : 'bg-purple-600 hover:bg-purple-700 text-white hover:shadow-lg'
                                        }`}
                                     >
                                        {isConnecting === 'd365' ? (
                                            <><i className="fas fa-spinner fa-spin"></i><span>Connecting...</span></>
                                        ) : d365Status === 'connected' ? (
                                            <span>Target Connected</span>
                                        ) : (
                                            <span>Connect Target</span>
                                        )}
                                     </button>

                                </div>
                            </div>
                        
                        </div>

                        {/* Action Bar (Centered) */}
                        {isConnectedAll && (
                            <div className="flex justify-center pt-8 animate-bounce-in">
                                <button
                                    onClick={() => onConnect('analyze')}
                                    disabled={isConnecting === 'analyze'}
                                    className="px-10 py-4 bg-slate-900 text-white text-lg font-bold rounded-full shadow-2xl hover:shadow-black/50 hover:-translate-y-1 transition-all flex items-center space-x-4 ring-4 ring-white"
                                >
                                    {isConnecting === 'analyze' ? (
                                        <><div className="loader border-white/30 border-t-white h-6 w-6"></div><span>Analyzing Scema...</span></>
                                    ) : (
                                        <><i className="fa-solid fa-wand-magic-sparkles text-yellow-400"></i><span>Start AI Analysis</span></>
                                    )}
                                </button>
                            </div>
                        )}

                    </div>
                </div>
            );
"""

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

start_marker = "            return ("
end_marker = "        };"

start_idx = content.find(start_marker)
# Find the end marker AFTER the start marker
end_idx = content.find(end_marker, start_idx) 

if start_idx != -1 and end_idx != -1:
    new_content = content[:start_idx] + new_return_block + "\n" + content[end_idx:]
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(new_content)
    print("SUCCESS")
else:
    print("MARKERS NOT FOUND")
