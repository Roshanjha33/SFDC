import os

file_path = "index.html"
new_return_block = r"""            return (
                <div className="flex flex-col items-center justify-center min-h-screen p-4 space-y-8 animate-fade-in bg-slate-50">
                    
                    {/* Salesforce Connector Card (Microsoft Style) - OATH ONLY */}
                    <div className="bg-white rounded-lg shadow-xl border border-slate-200 w-full max-w-2xl transform transition-all overflow-hidden relative">
                        {/* Status Badge */}
                        {sfStatus === 'connected' && (
                             <div className="absolute top-0 right-0 bg-green-500 text-white px-3 py-1 text-xs font-bold rounded-bl-lg shadow-sm z-10">
                                CONNECTED
                            </div>
                        )}

                        {/* Header Bar */}
                        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
                            <div className="flex items-center space-x-2">
                                <span className="text-[#00A1E0] text-3xl"><i className="fa-brands fa-salesforce"></i></span>
                                <h1 className="text-xl font-semibold text-slate-800">Connect to Salesforce</h1>
                            </div>
                            <div className="flex items-center space-x-2 text-xs text-slate-500">
                                <span>Microsoft</span>
                                <span className="border-l border-slate-100/10 h-3 mx-2"></span>
                                <span><i className="fa-solid fa-ribbon text-yellow-500 mr-1"></i>Premium</span>
                            </div>
                        </div>

                        {/* Main Content */}
                        <div className="p-8">
                            <div className="flex flex-col items-center mb-6">
                                <div className="text-[#00A1E0] text-6xl mb-4 drop-shadow-sm">
                                    <i className="fa-brands fa-salesforce"></i>
                                </div>
                                <h2 className="text-2xl font-bold text-slate-800 mb-2">Salesforce</h2>
                                <p className="text-slate-500 text-center max-w-md text-sm">
                                    Sign in with your Salesforce account to authorize the connection.
                                </p>
                            </div>

                            <div className="space-y-5 max-w-md mx-auto">
                                {/* Authentication Type - READ ONLY */}
                                <div>
                                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Authentication Type</label>
                                    <div className="relative">
                                        <div className="w-full pl-4 pr-10 py-2.5 bg-slate-100 border border-slate-300 rounded-md text-slate-500 font-medium cursor-not-allowed">
                                            Login with Salesforce Account (OAuth)
                                        </div>
                                    </div>
                                </div>

                                {/* Login URI */}
                                <div>
                                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Login URI (Environment)</label>
                                    <div className="relative">
                                        <select 
                                            value={environment}
                                            onChange={(e) => setEnvironment(e.target.value)}
                                            className="w-full pl-4 pr-10 py-2.5 bg-white border border-slate-300 rounded-md text-slate-700 focus:ring-2 focus:ring-[#00A1E0] focus:border-[#00a1e0] appearance-none shadow-sm cursor-pointer transition-shadow"
                                        >
                                            <option value="production">Production</option>
                                            <option value="sandbox">Sandbox</option>
                                        </select>
                                        <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-slate-500">
                                            <i className="fa-solid fa-chevron-down text-xs"></i>
                                        </div>
                                    </div>
                                </div>

                                {/* API Version */}
                                <div>
                                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Salesforce API Version</label>
                                    <div className="relative">
                                        <select 
                                            value={apiVersion}
                                            onChange={(e) => setApiVersion(e.target.value)}
                                            className="w-full pl-4 pr-10 py-2.5 bg-white border border-slate-300 rounded-md text-slate-700 focus:ring-2 focus:ring-[#00A1E0] focus:border-[#00a1e0] appearance-none shadow-sm cursor-pointer transition-shadow"
                                        >
                                            <option value="v58.0">v58.0</option>
                                            <option value="v59.0">v59.0</option>
                                            <option value="v60.0">v60.0</option>
                                        </select>
                                        <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-slate-500">
                                            <i className="fa-solid fa-chevron-down text-xs"></i>
                                        </div>
                                    </div>
                                </div>

                                {/* Error Display */}
                                {errorMessage && (
                                    <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded-r-md animate-fade-in shadow-sm">
                                        <div className="flex">
                                            <div className="flex-shrink-0">
                                                <i className="fa-solid fa-circle-exclamation text-red-500"></i>
                                            </div>
                                            <div className="ml-3">
                                                <h3 className="text-sm font-medium text-red-800">Connection Failed</h3>
                                                <div className="mt-1 text-sm text-red-700 opacity-90">{errorMessage}</div>
                                            </div>
                                        </div>
                                    </div>
                                )}

                            </div>
                        </div>

                        {/* Footer */}
                        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end space-x-3">
                             <button className="px-4 py-2 bg-white border border-slate-300 rounded-md text-slate-700 font-medium hover:bg-slate-50 shadow-sm transition-colors text-sm">
                                Cancel
                            </button>
                            <button 
                                onClick={handleSignIn}
                                disabled={isConnecting === 'sf' || sfStatus === 'connected'}
                                className={`px-6 py-2 rounded-md font-medium shadow-sm transition-colors flex items-center text-sm ${
                                    sfStatus === 'connected' 
                                    ? 'bg-green-600 text-white cursor-default'
                                    : 'bg-[#0078D4] hover:bg-[#006cbd] text-white'
                                } ${isConnecting === 'sf' ? 'opacity-75 cursor-not-allowed' : ''}`}
                            >
                                {isConnecting === 'sf' ? (
                                    <><i className="fa-solid fa-circle-notch fa-spin mr-2"></i> Connecting...</>
                                ) : sfStatus === 'connected' ? (
                                    <><i className="fas fa-check mr-2"></i> Connected</>
                                ) : (
                                    'Sign In with Salesforce'
                                )}
                            </button>
                        </div>
                    </div>


                    {/* Target: Dynamics 365 (Simplified Card below) */}
                    <div className={`w-full max-w-2xl bg-white rounded-lg border p-6 flex items-center justify-between transition-all ${d365Status === 'connected' ? 'border-green-400 shadow-green-50' : 'border-slate-200 hover:shadow-md'}`}>
                         <div className="flex items-center space-x-4">
                            <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center text-purple-600 text-2xl">
                                <i className="fa-brands fa-microsoft"></i>
                            </div>
                            <div>
                                <h3 className="font-semibold text-slate-800">Dynamics 365 Target</h3>
                                <p className="text-sm text-slate-500">{d365Creds.url}</p>
                            </div>
                         </div>
                         <button 
                            onClick={() => onConnect('d365', d365Creds)}
                            disabled={d365Status === 'connected' || isConnecting === 'd365'}
                            className={`px-4 py-2 rounded-lg text-sm font-medium border transition-colors ${
                                d365Status === 'connected'
                                ? 'bg-green-50 text-green-700 border-green-200'
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                            }`}
                         >
                            {isConnecting === 'd365' ? <i className="fas fa-spinner fa-spin"></i> : d365Status === 'connected' ? 'Connected' : 'Connect'}
                         </button>
                    </div>

                    {/* Action Button */}
                    {isConnectedAll && (
                         <div className="fixed bottom-8 animate-bounce-in">
                            <button
                                onClick={() => onConnect('analyze')}
                                disabled={isConnecting === 'analyze'}
                                className="px-8 py-3 bg-slate-900 text-white text-lg font-bold rounded-full shadow-2xl hover:shadow-black/50 hover:-translate-y-1 transition-all flex items-center space-x-3"
                            >
                                {isConnecting === 'analyze' ? (
                                    <><div className="loader border-white/30 border-t-white h-5 w-5"></div><span>Analyzing...</span></>
                                ) : (
                                    <><i className="fa-solid fa-wand-magic-sparkles"></i><span>Start Analysis</span></>
                                )}
                            </button>
                        </div>
                    )}
                </div>
            );
"""

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

start_marker = "            return ("
end_marker = "        };"

start_idx = content.find(start_marker)
# Find the end marker AFTER the start marker
end_idx = content.find(end_marker, start_idx) 

if start_idx != -1 and end_idx != -1:
    new_content = content[:start_idx] + new_return_block + "\n" + content[end_idx:]
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(new_content)
    print("SUCCESS")
else:
    print("MARKERS NOT FOUND")
