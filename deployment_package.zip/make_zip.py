
import shutil
import os

def zip_project():
    # Zipping the current directory
    # skipping __pycache__ and venv if any
    
    base_dir = os.getcwd()
    output_filename = os.path.join(base_dir, 'deployment_package')
    
    # helper to filter
    def start_zip():
        shutil.make_archive(output_filename, 'zip', base_dir)
        print(f"Created {output_filename}.zip")

    start_zip()

if __name__ == '__main__':
    zip_project()
