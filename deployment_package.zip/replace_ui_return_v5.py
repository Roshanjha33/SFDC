import os

file_path = "index.html"
new_return_block = r"""            return (
                <div className="min-h-screen bg-[#F5F7FA] flex flex-col items-center justify-center p-8 animate-fade-in font-sans selection:bg-blue-100">
                    
                    <div className="w-full max-w-7xl space-y-12">
                        {/* Header */}
                        <div className="text-center space-y-3 mb-12">
                            <h1 className="text-4xl font-light text-slate-800 tracking-tight">
                                <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#00A1E0] to-[#0078D4]">CRM</span> Intelligence Bridge
                            </h1>
                            <p className="text-slate-500 text-lg font-light">Harmonize your customer data across platforms</p>
                        </div>

                        {/* Main Grid: Side-by-Side Connectors */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-stretch">
                            
                            {/* LEFT: Salesforce Connector */}
                            <div className="group bg-white rounded-2xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.08)] border border-slate-100 overflow-hidden relative transition-all duration-300 hover:shadow-[0_20px_60px_-15px_rgba(0,161,224,0.15)] hover:-translate-y-1">
                                {/* Top Accent */}
                                <div className={`h-1.5 w-full transition-colors duration-500 ${sfStatus === 'connected' ? 'bg-gradient-to-r from-green-400 to-emerald-500' : 'bg-gradient-to-r from-[#00A1E0] to-[#0078D4]'}`}></div>
                                
                                <div className="p-10 flex flex-col h-full">
                                    <div className="flex items-center justify-between mb-8">
                                        <div className="flex items-center space-x-4">
                                            <div className="h-14 w-14 bg-blue-50 rounded-xl flex items-center justify-center text-[#00A1E0] text-3xl shadow-sm group-hover:scale-110 transition-transform duration-300">
                                                <i className="fa-brands fa-salesforce"></i>
                                            </div>
                                            <div>
                                                <h2 className="text-2xl font-bold text-slate-800">Salesforce</h2>
                                                <div className="flex items-center space-x-2 mt-1">
                                                    <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase bg-slate-50 px-2 py-0.5 rounded border border-slate-100">Source</span>
                                                </div>
                                            </div>
                                        </div>
                                        {sfStatus === 'connected' && (
                                            <div className="flex items-center space-x-2 bg-green-50 text-green-700 px-4 py-1.5 rounded-full text-xs font-bold border border-green-100 shadow-sm animate-fade-in-up">
                                                <span className="relative flex h-2 w-2">
                                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                                                </span>
                                                <span>CONNECTED</span>
                                            </div>
                                        )}
                                    </div>

                                    <div className="flex-grow space-y-6">
                                        <div>
                                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Authentication Method</label>
                                            <div className="relative group/select">
                                                <select 
                                                    value={authType} 
                                                    onChange={(e) => setAuthType(e.target.value)}
                                                    className="w-full pl-4 pr-10 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-700 outline-none focus:ring-2 focus:ring-[#00A1E0]/20 focus:border-[#00a1e0] appearance-none cursor-pointer font-medium text-sm transition-all shadow-sm"
                                                >
                                                    <option value="demo">Demo / Simulation (Offline)</option>
                                                    <option value="oauth">Login with Salesforce Account</option>
                                                </select>
                                                <div className="absolute inset-y-0 right-0 flex items-center px-4 pointer-events-none text-slate-400 transition-transform group-hover/select:translate-y-0.5">
                                                    <i className="fa-solid fa-chevron-down text-xs"></i>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Status Card */}
                                        <div className={`rounded-xl p-6 border transition-all duration-300 ${authType === 'demo' ? 'bg-blue-50/50 border-blue-100' : 'bg-slate-50 border-slate-100'}`}>
                                            {authType === 'demo' ? (
                                                <div className="flex items-start space-x-4 animate-fade-in">
                                                    <div className="p-2 bg-white rounded-lg shadow-sm text-blue-500">
                                                        <i className="fa-solid fa-flask text-lg"></i>
                                                    </div>
                                                    <div>
                                                        <p className="font-semibold text-slate-800 mb-1">Contoso Demo Org</p>
                                                        <p className="text-xs text-slate-500 leading-relaxed">
                                                            Simulated environment with pre-populated schema. Ideal for testing mapping logic instantly.
                                                        </p>
                                                    </div>
                                                </div>
                                            ) : (
                                                <div className="flex items-start space-x-4 animate-fade-in">
                                                    <div className="p-2 bg-white rounded-lg shadow-sm text-[#00A1E0]">
                                                        <i className="fa-solid fa-globe text-lg"></i>
                                                    </div>
                                                    <div className="w-full">
                                                        <div className="flex justify-between items-center mb-1">
                                                            <p className="font-semibold text-slate-800">Live Environment</p>
                                                            <select 
                                                                value={environment}
                                                                onChange={(e) => setEnvironment(e.target.value)}
                                                                className="text-[10px] bg-white border border-slate-200 rounded px-2 py-0.5 focus:border-[#00A1E0] outline-none"
                                                            >
                                                                <option value="production">Production</option>
                                                                <option value="sandbox">Sandbox</option>
                                                            </select>
                                                        </div>
                                                        <p className="text-xs text-slate-500 leading-relaxed">
                                                            Secure OAuth 2.0 connection. Redirects to Salesforce for authorization.
                                                        </p>
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        {/* Error Toast */}
                                        {errorMessage && (
                                            <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg animate-slide-in-right flex items-start space-x-3">
                                                <i className="fa-solid fa-circle-exclamation text-red-500 mt-0.5"></i>
                                                <div className="text-xs text-red-700 font-medium">{errorMessage}</div>
                                            </div>
                                        )}
                                    </div>

                                    {/* Action Button */}
                                    <div className="mt-8">
                                        <button 
                                            onClick={handleSignIn}
                                            disabled={isConnecting === 'sf' || sfStatus === 'connected'}
                                            className={`w-full py-4 rounded-xl font-bold shadow-lg transition-all transform active:scale-[0.98] flex items-center justify-center space-x-3 text-sm tracking-wide ${
                                                sfStatus === 'connected' 
                                                ? 'bg-slate-100 text-slate-400 cursor-default shadow-none border border-slate-200'
                                                : 'bg-gradient-to-r from-[#00A1E0] to-[#008CC9] hover:from-[#008CC9] hover:to-[#0077AB] text-white hover:shadow-blue-500/25'
                                            } ${isConnecting === 'sf' ? 'opacity-80 cursor-wait' : ''}`}
                                        >
                                            {isConnecting === 'sf' ? (
                                                <><i className="fa-solid fa-circle-notch fa-spin"></i><span>CONNECTING...</span></>
                                            ) : sfStatus === 'connected' ? (
                                                <span>AUTHORIZED</span>
                                            ) : (
                                                <span>{authType === 'demo' ? 'CONNECT SIMULATION' : 'SIGN IN WITH SALESFORCE'}</span>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            </div>

                            {/* RIGHT: Dynamics 365 Connector */}
                            <div className="group bg-white rounded-2xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.08)] border border-slate-100 overflow-hidden relative transition-all duration-300 hover:shadow-[0_20px_60px_-15px_rgba(124,58,237,0.15)] hover:-translate-y-1">
                                {/* Top Accent */}
                                <div className={`h-1.5 w-full transition-colors duration-500 ${d365Status === 'connected' ? 'bg-gradient-to-r from-green-400 to-emerald-500' : 'bg-gradient-to-r from-[#7c3aed] to-[#6d28d9]'}`}></div>

                                <div className="p-10 flex flex-col h-full">
                                    <div className="flex items-center justify-between mb-8">
                                        <div className="flex items-center space-x-4">
                                            <div className="h-14 w-14 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600 text-3xl shadow-sm group-hover:scale-110 transition-transform duration-300">
                                                <i className="fa-brands fa-microsoft"></i>
                                            </div>
                                            <div>
                                                <h2 className="text-2xl font-bold text-slate-800">Dynamics 365</h2>
                                                <div className="flex items-center space-x-2 mt-1">
                                                    <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase bg-slate-50 px-2 py-0.5 rounded border border-slate-100">Target</span>
                                                </div>
                                            </div>
                                        </div>
                                        {d365Status === 'connected' && (
                                            <div className="flex items-center space-x-2 bg-green-50 text-green-700 px-4 py-1.5 rounded-full text-xs font-bold border border-green-100 shadow-sm animate-fade-in-up">
                                                <span className="relative flex h-2 w-2">
                                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                                                </span>
                                                <span>CONNECTED</span>
                                            </div>
                                        )}
                                    </div>

                                    <div className="flex-grow space-y-6">
                                        <div>
                                            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Target Environment</label>
                                            <div className="bg-purple-50/50 rounded-xl p-6 border border-purple-100/50 min-h-[140px] flex flex-col justify-center transition-colors group-hover:bg-purple-50">
                                                 <div className="flex items-center space-x-4 mb-3">
                                                    <div className="h-10 w-10 bg-white rounded-lg flex items-center justify-center shadow-sm text-purple-600">
                                                        <i className="fa-solid fa-server"></i>
                                                    </div>
                                                    <div>
                                                        <p className="text-sm font-bold text-slate-800">Contoso Sales</p>
                                                        <p className="text-[10px] text-slate-500 font-mono bg-white/50 px-1 rounded inline-block">{d365Creds.url}</p>
                                                    </div>
                                                 </div>
                                                 <p className="text-xs text-slate-500 leading-relaxed border-t border-purple-100 pt-3 mt-1">
                                                    User: <strong>Global Admin</strong><br/>
                                                    Permissions: <strong>Read/Write</strong> (Account, Contact, Lead)
                                                 </p>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Action Button */}
                                    <div className="mt-8">
                                        <button 
                                            onClick={() => onConnect('d365', d365Creds)}
                                            disabled={d365Status === 'connected' || isConnecting === 'd365'}
                                            className={`w-full py-4 rounded-xl font-bold shadow-lg transition-all transform active:scale-[0.98] flex items-center justify-center space-x-3 text-sm tracking-wide ${
                                                d365Status === 'connected'
                                                ? 'bg-slate-100 text-slate-400 cursor-default shadow-none border border-slate-200'
                                                : 'bg-gradient-to-r from-[#7c3aed] to-[#6d28d9] hover:from-[#6d28d9] hover:to-[#5b21b6] text-white hover:shadow-purple-500/25'
                                            }`}
                                         >
                                            {isConnecting === 'd365' ? (
                                                <><i className="fas fa-spinner fa-spin"></i><span>CONNECTING...</span></>
                                            ) : d365Status === 'connected' ? (
                                                <span>AUTHORIZED</span>
                                            ) : (
                                                <span>CONNECT TARGET</span>
                                            )}
                                         </button>
                                    </div>

                                </div>
                            </div>
                        
                        </div>

                        {/* Analysis Trigger (Centered) */}
                        {isConnectedAll && (
                            <div className="flex justify-center pt-4 animate-bounce-in-up pb-12">
                                <button
                                    onClick={() => onConnect('analyze')}
                                    disabled={isConnecting === 'analyze'}
                                    className="group relative px-12 py-5 bg-slate-900 overflow-hidden rounded-full shadow-2xl hover:shadow-[0_20px_50px_-12px_rgba(0,0,0,0.5)] transition-all hover:-translate-y-1"
                                >
                                    <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                                    <div className="flex items-center space-x-4">
                                        {isConnecting === 'analyze' ? (
                                            <div className="loader border-white/30 border-t-white h-6 w-6"></div>
                                        ) : (
                                            <i className="fa-solid fa-wand-magic-sparkles text-yellow-400 text-xl group-hover:rotate-12 transition-transform"></i>
                                        )}
                                        <span className="text-white text-lg font-bold tracking-wide">
                                            {isConnecting === 'analyze' ? 'Running Analysis...' : 'Start AI Analysis'}
                                        </span>
                                    </div>
                                </button>
                            </div>
                        )}

                    </div>
                    
                    {/* Footer / Copyright */}
                    <div className="fixed bottom-4 text-center w-full pointer-events-none opacity-50">
                        <p className="text-[10px] text-slate-400 font-medium tracking-widest uppercase">Powered by Gemini Cortex</p>
                    </div>
                </div>
            );
"""

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

start_marker = "            return ("
end_marker = "        };"

start_idx = content.find(start_marker)
# Find the end marker AFTER the start marker
end_idx = content.find(end_marker, start_idx) 

if start_idx != -1 and end_idx != -1:
    new_content = content[:start_idx] + new_return_block + "\n" + content[end_idx:]
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(new_content)
    print("SUCCESS")
else:
    print("MARKERS NOT FOUND")
