import http.server
import socketserver
import json
import urllib.request
import urllib.parse
import urllib.error
import xml.etree.ElementTree as ET
import os
import ssl

PORT = int(os.environ.get('PORT', 8081))

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        print(f"---------> [POST] Request received: {self.path}")
        # Helper to send JSON response
        def send_json(status, data):
            self.send_response(status)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(data).encode('utf-8'))

        if self.path == '/api/sf/login':
            try:
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))

                username = data.get('username')
                password = data.get('password')
                client_id = data.get('client_id')
                login_url_base = data.get('login_url', 'https://login.salesforce.com')

                print(f"[-] Attempting login for user: {username} on {login_url_base}")

                # STRATEGY 1: OAuth (if Client ID provided)
                if client_id:
                    print("[-] Using OAuth PWD Flow")
                    token_url = f"{login_url_base}/services/oauth2/token"
                    payload = urllib.parse.urlencode({
                        'grant_type': 'password',
                        'client_id': client_id,
                        'client_secret': data.get('client_secret'),
                        'username': username,
                        'password': password
                    }).encode('utf-8')
                    
                    req = urllib.request.Request(token_url, data=payload, method='POST')
                    with urllib.request.urlopen(req) as response:
                        send_json(200, json.loads(response.read()))
                    return

                # STRATEGY 2: SOAP Login
                else:
                    print("[-] Using SOAP Login Flow")
                    soap_url = f"{login_url_base}/services/Soap/u/59.0"
                    soap_body = f"""<?xml version="1.0" encoding="utf-8" ?>
                    <env:Envelope xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                        xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
                        <env:Body>
                            <n1:login xmlns:n1="urn:partner.soap.sforce.com">
                                <n1:username>{username}</n1:username>
                                <n1:password>{password}</n1:password>
                            </n1:login>
                        </env:Body>
                    </env:Envelope>""".encode('utf-8')

                    headers = {
                        'Content-Type': 'text/xml; charset=UTF-8',
                        'SOAPAction': 'login'
                    }

                    # Create SSL context to be permissive if needed, though default usually fine
                    ctx = ssl.create_default_context()
                    
                    req = urllib.request.Request(soap_url, data=soap_body, headers=headers, method='POST')
                    with urllib.request.urlopen(req, context=ctx) as response:
                        xml_response = response.read()
                        root = ET.fromstring(xml_response)
                        
                        ns = {
                            'soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
                            'urn': 'urn:partner.soap.sforce.com'
                        }
                        
                        result = root.find('.//urn:result', ns)
                        if result is None:
                            print("[!] Could not find result in XML response")
                            send_json(500, {'error': 'Invalid XML response from Salesforce'})
                            return

                        session_id = result.find('urn:sessionId', ns).text
                        server_url = result.find('urn:serverUrl', ns).text
                        
                        parsed = urllib.parse.urlparse(server_url)
                        instance_url = f"{parsed.scheme}://{parsed.netloc}"
                        
                        print(f"[+] Login Successful! Instance: {instance_url}")
                        send_json(200, {
                            'access_token': session_id,
                            'instance_url': instance_url
                        })
                        return

            except urllib.error.HTTPError as e:
                error_content = e.read().decode('utf-8')
                print(f"[!] Salesforce HTTP Error {e.code}: {error_content}")
                
                # Try to parse SOAP Fault
                try:
                    root = ET.fromstring(error_content)
                    fault_string = root.find('.//faultstring').text
                    send_json(400, {'error': f"Salesforce Error: {fault_string}"})
                except:
                    # Try to parse OAuth JSON error
                    try:
                        err_json = json.loads(error_content)
                        send_json(400, {'error': f"{err_json.get('error')}: {err_json.get('error_description')}"})
                    except:
                        send_json(400, {'error': f"Login Failed (HTTP {e.code})"})
                return
            except Exception as e:
                print(f"[!] Server Error: {str(e)}")
                send_json(500, {'error': f"Internal Proxy Error: {str(e)}"})
                return

        if self.path == '/api/sf/metadata':
            try:
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))

                instance_url = data.get('instance_url')
                access_token = data.get('access_token')
                
                print(f"[-] Fetching metadata from {instance_url}")
                
                api_url = f"{instance_url}/services/data/v60.0/sobjects/"
                req = urllib.request.Request(api_url)
                req.add_header('Authorization', f'Bearer {access_token}')
                
                with urllib.request.urlopen(req) as response:
                    sobjects_data = json.loads(response.read().decode('utf-8'))
                    
                    entities = []
                    count = 0 
                    for sobj in sobjects_data.get('sobjects', []):
                        if count > 30: break 
                        if sobj['triggerable'] and sobj['createable']:
                            entities.append({
                                'name': sobj['name'],
                                'label': sobj['label'],
                                'fields': 0 
                            })
                            count += 1
                            
                    print(f"[+] Metadata fetched: {len(entities)} entities")
                    send_json(200, entities)

            except Exception as e:
                print(f"[!] Metadata Error: {str(e)}")
                send_json(500, {'error': str(e)})
            return

        return http.server.SimpleHTTPRequestHandler.do_POST(self)

print(f"Serving at port {PORT}")
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    httpd.serve_forever()
